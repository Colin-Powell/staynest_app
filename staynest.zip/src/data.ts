import { Property } from './types';

export const properties: Property[] = [
  {
    id: '1',
    name: '11 Green Bank',
    location: 'Boston, MA',
    lat: 42.3601,
    lng: -71.0589,
    price: 14500,
    rating: 4.8,
    reviews: 120,
    category: 'Apartment',
    image: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&q=80&w=1000',
    features: { beds: 2, rooms: 4, baths: 2, furnished: true },
    amenities: ['wifi', 'water', 'parking', 'security'],
    description: 'Modern luxury apartment in the heart of Boston. Close to public transport, schools, and markets.',
    agent: { name: 'John Kamau', avatar: 'https://i.pravatar.cc/150?img=11' }
  },
  {
    id: '2',
    name: 'Sunset Apartment',
    location: 'New York, USA',
    lat: 40.7128,
    lng: -74.0060,
    price: 12000,
    rating: 4.6,
    reviews: 85,
    category: 'Apartment',
    image: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=1000',
    features: { beds: 3, rooms: 3, baths: 2, furnished: true },
    amenities: ['wifi', 'water', 'security'],
    description: 'Beautiful sunset views from this spacious apartment in NYC. Located in a secure gated community.',
    agent: { name: 'Mary Wanjiku', avatar: 'https://i.pravatar.cc/150?img=32' }
  },
  {
    id: '3',
    name: 'Modern Studio',
    location: 'Brooklyn, NY',
    lat: 40.6782,
    lng: -73.9442,
    price: 8000,
    rating: 4.5,
    reviews: 64,
    category: 'Studio',
    image: 'https://images.unsplash.com/photo-1536376072261-38c75010e6c9?auto=format&fit=crop&q=80&w=1000',
    features: { beds: 1, rooms: 1, baths: 1, furnished: false },
    amenities: ['wifi', 'water'],
    description: 'Minimalist studio perfect for young professionals looking for a modern and compact living space.',
    agent: { name: 'David Ochieng', avatar: 'https://i.pravatar.cc/150?img=68' }
  }
];

export const formatPrice = (price: number) => {
  if (price >= 1000) {
    // If it's a clean multiple of 1000 (like 12000 -> 12k)
    // If it has hundreds (like 14500 -> 14.5k)
    const thousands = price / 1000;
    return `$${thousands.toFixed(thousands % 1 !== 0 ? 1 : 0)}k`;
  }
  return `$${price}`;
};
