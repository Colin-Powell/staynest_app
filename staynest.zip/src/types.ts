export interface Agent {
  name: string;
  avatar: string;
}

export interface PropertyFeatures {
  beds: number;
  rooms?: number;
  baths: number;
  furnished: boolean;
}

export interface Property {
  id: string;
  name: string;
  location: string;
  lat?: number;
  lng?: number;
  price: number; // per month
  rating: number;
  reviews: number;
  category: string;
  image: string;
  images?: string[];
  features: PropertyFeatures;
  amenities: string[];
  description: string;
  agent: Agent;
}
