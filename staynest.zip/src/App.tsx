import { Bookmark, Home, MessageSquare, Search, User, Building } from 'lucide-react';
import React, { useState } from 'react';
import HomeView from './components/HomeView';
import PropertyDetails from './components/PropertyDetails';
import SearchView from './components/SearchView';
import SavedView from './components/SavedView';
import MessagesView from './components/MessagesView';
import ProfileView from './components/ProfileView';
import ChatView from './components/ChatView';
import NotificationsView from './components/NotificationsView';
import MyBookingsView from './components/MyBookingsView';
import LandlordDashboardView from './components/LandlordDashboardView';
import LandlordPropertiesView from './components/LandlordPropertiesView';
import AddPropertyView from './components/AddPropertyView';
import SettingView from './components/SettingView';
import EditProfileView from './components/EditProfileView';
import PaymentMethodsView from './components/PaymentMethodsView';
import ReviewsView from './components/ReviewsView';
import HelpSupportView from './components/HelpSupportView';
import Alert, { AlertType } from './components/Alert';
import OnboardingView from './components/OnboardingView';
import LoginView from './components/LoginView';
import RegisterView from './components/RegisterView';
import OtpView from './components/OtpView';
import BookingView from './components/BookingView';
import SplashView from './components/SplashView';
import RoleSelectionView from './components/RoleSelectionView';
import AdminDashboardView from './components/AdminDashboardView';
import CallingView from './components/CallingView';
import AmenitiesView from './components/AmenitiesView';
import PhotoGalleryView from './components/PhotoGalleryView';
import LocationView from './components/LocationView';
import LandlordInfoView from './components/LandlordInfoView';
import NearbyServicesView from './components/NearbyServicesView';
import CommuteMethodsView from './components/CommuteMethodsView';
import WriteReviewView from './components/WriteReviewView';
import LandlordReviewsView from './components/LandlordReviewsView';
import MoreFiltersView from './components/MoreFiltersView';
import FilterView from './components/FilterView';

export default function App() {
  const [view, setView] = useState<'splash' | 'role_selection' | 'onboarding' | 'login' | 'register' | 'otp' | 'home' | 'details' | 'search' | 'saved' | 'messages' | 'profile' | 'chat' | 'notifications' | 'my-bookings' | 'landlord_dashboard' | 'landlord_properties' | 'add_property' | 'setting' | 'Edit Profile' | 'Payment Methods' | 'Reviews' | 'Help & Support' | 'Personal Information' | 'admin_dashboard' | 'calling' | 'Amenities' | 'Photo Gallery' | 'Location' | 'Landlord Info' | 'Nearby Services' | 'Commute Methods' | 'Analytics' | 'Write a Review' | 'Landlord Reviews' | 'More Filters'>('splash');
  const [selectedPropId, setSelectedPropId] = useState<string | null>(null);
  const [showBooking, setShowBooking] = useState(false);
  const [chatInfo, setChatInfo] = useState<{name: string, avatar: string} | null>(null);
  const [chatOrigin, setChatOrigin] = useState<'messages'|'details'>('messages');
  const [settingTitle, setSettingTitle] = useState('');
  const [role, setRole] = useState<'tenant'|'landlord'>('tenant');
  const [alert, setAlert] = useState<{ type: AlertType; message: string } | null>(null);
  const [isMapVisible, setIsMapVisible] = useState(false);

  const showAlert = (type: AlertType, message: string) => {
    setAlert({ type, message });
  };

  const handleSelectProperty = (id: string) => {
    setSelectedPropId(id);
    setView('details');
  };

  const handleBack = () => {
    setSelectedPropId(null);
    setView(role === 'tenant' ? 'home' : 'landlord_properties');
  };

  // hide bottom nav in these views
  const hideNavViews = ['splash', 'role_selection', 'onboarding', 'login', 'register', 'otp', 'details', 'chat', 'calling', 'notifications', 'my-bookings', 'add_property', 'setting', 'Edit Profile', 'Payment Methods', 'Reviews', 'Help & Support', 'Personal Information', 'Amenities', 'Photo Gallery', 'Location', 'Landlord Info', 'Nearby Services', 'Commute Methods', 'Analytics', 'Write a Review', 'Landlord Reviews', 'More Filters'];
  const shouldShowNav = !hideNavViews.includes(view) && !isMapVisible;

  return (
    <div className="min-h-screen bg-neutral-800 flex items-center justify-center sm:py-8 font-sans">
      {/* Mobile App Container Frame */}
      <div className="w-full sm:w-[414px] h-[100dvh] sm:h-[896px] bg-slate-50 sm:rounded-[2.5rem] sm:shadow-[0_0_50px_-12px_rgba(0,0,0,0.5)] sm:border-[12px] border-black overflow-hidden relative flex flex-col items-center">
        
        {/* Custom Notifications Bubble Component Overlay */}
        {alert && <Alert type={alert.type} message={alert.message} onClose={() => setAlert(null)} />}
        
        {/* Dynamic Island / Notch Fake */}
        <div className="hidden sm:block absolute top-0 left-1/2 -translate-x-1/2 w-[120px] h-[30px] bg-black rounded-b-3xl z-50"></div>

        {/* View Routing */}
        {view === 'splash' && <SplashView onNext={() => setView('onboarding')} />}
        {view === 'onboarding' && <OnboardingView onFinish={() => setView('role_selection')} />}
        {view === 'role_selection' && <RoleSelectionView onBack={() => setView('onboarding')} onSelect={(r) => { 
            setRole(r === 'admin' ? 'tenant' : r); 
            if (r === 'admin') setView('admin_dashboard');
            else setView('login');
        }} />}
        {view === 'login' && <LoginView onLogin={() => { setView(role === 'landlord' ? 'landlord_dashboard' : 'home'); showAlert('success', 'Logged in successfully!'); }} onRegister={() => setView('register')} />}
        {view === 'register' && <RegisterView onRegister={() => setView('otp')} onLogin={() => setView('login')} />}
        {view === 'otp' && <OtpView onVerify={() => { setView('home'); showAlert('success', 'Account verified successfully!'); }} onBack={() => setView('register')} />}
        
        {view === 'home' && <HomeView onSelectProperty={handleSelectProperty} onNotifications={() => setView('notifications')} />}
        {view === 'details' && selectedPropId && (
          <>
             <PropertyDetails id={selectedPropId} onBack={handleBack} onBook={() => setShowBooking(true)} onMessage={() => { setChatInfo({ name: 'Agent', avatar: 'https://i.pravatar.cc/150?img=11' }); setChatOrigin('details'); setView('chat'); }} onViewAmenities={() => setView('Amenities')} onViewGallery={() => setView('Photo Gallery')} onViewLocation={() => setView('Location')} onViewLandlord={() => setView('Landlord Info')} />
             {showBooking && <BookingView propertyId={selectedPropId} onBack={() => setShowBooking(false)} onComplete={() => { setShowBooking(false); setSelectedPropId(null); showAlert('success', 'Booking Confirmed! 🎉'); setView('my-bookings'); }} />}
          </>
        )}
        
        {view === 'search' && <SearchView onSelectProperty={handleSelectProperty} onToggleMap={setIsMapVisible} onBack={() => setView('home')} onMoreFilters={() => setView('More Filters')} />}
        {view === 'saved' && <SavedView onSelectProperty={handleSelectProperty} />}
        {view === 'messages' && <MessagesView onSelectChat={(id, name, avatar) => { setChatInfo({name, avatar}); setChatOrigin('messages'); setView('chat'); }} />}
        {view === 'chat' && chatInfo && <ChatView name={chatInfo.name} avatar={chatInfo.avatar} onBack={() => setView(chatOrigin)} onCall={() => setView('calling')} />}
        {view === 'calling' && chatInfo && <CallingView name={chatInfo.name} avatar={chatInfo.avatar} onEndCall={() => setView('chat')} />}
        {view === 'profile' && <ProfileView onViewBookings={() => setView('my-bookings')} onSetting={(title) => { 
           if (['Edit Profile', 'Payment Methods', 'Reviews', 'Help & Support', 'Personal Information'].includes(title)) {
             setView(title as any);
           } else {
             setSettingTitle(title); 
             setView('setting'); 
           }
        }} onSwitchRole={() => { 
           const nextRole = role === 'tenant' ? 'landlord' : 'tenant';
           setRole(nextRole); 
           setView(nextRole === 'landlord' ? 'landlord_dashboard' : 'home'); 
           showAlert('info', `Switched to ${nextRole} view`);
        }} onViewSaved={() => setView('saved')} onLogout={() => { setRole('tenant'); setView('login'); showAlert('info', 'You have been logged out.'); }} />}
        {view === 'my-bookings' && <MyBookingsView onBack={() => setView('profile')} />}
        {view === 'notifications' && <NotificationsView onBack={() => setView('home')} />}
        {view === 'setting' && <SettingView title={settingTitle} onBack={() => setView('profile')} />}
        
        {view === 'admin_dashboard' && <AdminDashboardView />}
        {view === 'landlord_dashboard' && <LandlordDashboardView onAddProperty={() => setView('add_property')} />}
        {view === 'landlord_properties' && <LandlordPropertiesView onAddProperty={() => setView('add_property')} />}
        {view === 'add_property' && <AddPropertyView onBack={() => setView('landlord_properties')} onPublish={() => { showAlert('success', 'Property published successfully.'); setView('landlord_properties'); }} />}

        {/* Setting / Profile sub-views */}
        {view === 'Edit Profile' && <EditProfileView onBack={() => setView('profile')} onSave={() => { showAlert('success', 'Your profile has been updated successfully.'); setView('profile'); }} />}
        {view === 'Payment Methods' && <PaymentMethodsView onBack={() => setView('profile')} />}
        {view === 'Reviews' && <ReviewsView onBack={() => setView('profile')} onWriteReview={() => setView('Write a Review')} onLandlordReviews={() => setView('Landlord Reviews')} />}
        {view === 'Help & Support' && <HelpSupportView onBack={() => setView('profile')} />}
        {view === 'Personal Information' && <EditProfileView onBack={() => setView('profile')} onSave={() => { showAlert('success', 'Your info has been updated successfully.'); setView('profile'); }} />}
        {view === 'setting' && <SettingView title={settingTitle} onBack={() => setView('profile')} />}

        {/* Property Detail Sub-views */}
        {view === 'Amenities' && <AmenitiesView onClose={() => setView('details')} />}
        {view === 'Photo Gallery' && <PhotoGalleryView onClose={() => setView('details')} />}
        {view === 'Location' && <LocationView onClose={() => setView('details')} onNearbyPlaces={() => setView('Nearby Services')} onGetDirections={() => setView('Commute Methods')} />}
        {view === 'Landlord Info' && <LandlordInfoView onClose={() => setView('details')} />}
        
        {/* Review & Analytics views */}
        {view === 'Write a Review' && <WriteReviewView onClose={() => setView('Reviews')} onSubmit={() => { showAlert('success', 'Review submitted successfully.'); setView('Reviews'); }} />}
        {view === 'Landlord Reviews' && <LandlordReviewsView onClose={() => setView('Reviews')} />}
        
        {/* Shared / Search sub-views */}
        {view === 'Nearby Services' && <NearbyServicesView onClose={() => setView('Location')} />}
        {view === 'Commute Methods' && <CommuteMethodsView onClose={() => setView('Location')} />}
        {view === 'More Filters' && <MoreFiltersView onClose={() => setView('search')} />}

        {/* Bottom Navigation (Hidden when in details or auth view) */}
        {shouldShowNav && (
          <div className="absolute bottom-0 left-0 right-0 bg-white border-t border-gray-50 flex justify-between items-center px-8 py-5 pb-8 sm:pb-6 z-40 sm:rounded-b-[2rem] shadow-[0_-4px_25px_rgba(0,0,0,0.03)]">
            {role === 'tenant' ? (
              <>
                <NavItem icon={<Home />} label="Home" active={view === 'home'} onClick={() => setView('home')} />
                <NavItem icon={<Search />} label="Search" active={view === 'search'} onClick={() => setView('search')} />
                <NavItem icon={<Bookmark />} label="Saved" active={view === 'saved'} onClick={() => setView('saved')} />
                <NavItem icon={<MessageSquare />} label="Messages" active={view === 'messages'} onClick={() => setView('messages')} />
                <NavItem icon={<User />} label="Profile" active={view === 'profile'} onClick={() => setView('profile')} />
              </>
            ) : (
              <>
                <NavItem icon={<Home />} label="Dashboard" active={view === 'landlord_dashboard'} onClick={() => setView('landlord_dashboard')} />
                <NavItem icon={<Building />} label="Properties" active={view === 'landlord_properties'} onClick={() => setView('landlord_properties')} />
                <NavItem icon={<MessageSquare />} label="Messages" active={view === 'messages'} onClick={() => setView('messages')} />
                <NavItem icon={<User />} label="Profile" active={view === 'profile'} onClick={() => setView('profile')} />
              </>
            )}
          </div>
        )}

      </div>
    </div>
  );
}

function NavItem({ icon, label, active, onClick }: { icon: React.ReactNode, label: string, active: boolean, onClick: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={`flex flex-col items-center gap-1 transition-colors ${active ? 'text-primary' : 'text-gray-400 hover:text-gray-600'}`}
    >
      <div className={`[&>svg]:w-6 [&>svg]:h-6 ${active ? 'fill-primary/20' : 'fill-transparent'}`}>
        {icon}
      </div>
      <span className={`text-[10px] font-medium leading-none ${active ? 'text-primary' : ''}`}>{label}</span>
      {active && <div className="absolute top-[8px] w-1 h-1 rounded-full bg-primary -ml-8 hidden" />}
    </button>
  );
}

