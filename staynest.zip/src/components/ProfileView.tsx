import { User, Bookmark, Calendar, CreditCard, Star, Settings, HelpCircle, ChevronRight, LogOut } from 'lucide-react';

const MENU_ITEMS = [
  { icon: <User className="w-5 h-5" />, label: 'Personal Information' },
  { icon: <Bookmark className="w-5 h-5" />, label: 'Saved Properties' },
  { icon: <Calendar className="w-5 h-5" />, label: 'My Bookings' },
  { icon: <CreditCard className="w-5 h-5" />, label: 'Payment Methods' },
  { icon: <Star className="w-5 h-5" />, label: 'Reviews' },
  { icon: <Settings className="w-5 h-5" />, label: 'Settings' },
  { icon: <HelpCircle className="w-5 h-5" />, label: 'Help & Support' },
];

export default function ProfileView({ onViewBookings, onSwitchRole, onSetting, onViewSaved, onLogout }: { onViewBookings: () => void, onSwitchRole: () => void, onSetting: (name: string) => void, onViewSaved: () => void, onLogout: () => void }) {
  return (
    <div className="flex-1 overflow-y-auto w-full bg-slate-50 no-scrollbar pb-24 animate-in fade-in zoom-in-95 duration-200">
      <div className="px-6 pt-12 pb-4 bg-white/80 backdrop-blur-md sticky top-0 z-10 border-b border-gray-100 flex items-center justify-center">
          <h1 className="text-[17px] font-bold text-gray-900">Profile</h1>
      </div>

      <div className="px-6 py-6 pb-28">
        <div className="flex items-center gap-4 mb-8 bg-white p-5 rounded-[2rem] shadow-sm border border-gray-100 cursor-pointer hover:shadow-md transition-shadow">
          <img src="https://i.pravatar.cc/150?img=12" alt="Avatar" className="w-[72px] h-[72px] rounded-full object-cover shadow-sm" />
          <div className="flex-1" onClick={() => onSetting('Edit Profile')}>
            <h2 className="text-xl font-bold text-gray-900 mb-1">Jomision</h2>
            <p className="text-sm text-gray-500 font-semibold flex items-center gap-1 group">
              View and edit your profile <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
            </p>
          </div>
        </div>

        <div className="flex flex-col gap-2.5">
          <button onClick={onSwitchRole} className="group flex items-center justify-between p-4 px-5 bg-primary/10 rounded-2xl shadow-sm border border-primary/20 active:bg-primary/20 transition-colors mb-2">
              <div className="flex items-center gap-4">
                <div className="text-primary"><User className="w-5 h-5" /></div>
                <span className="font-bold text-primary text-[15px]">Switch Role</span>
              </div>
          </button>
          {MENU_ITEMS.map((item, i) => (
            <button key={i} onClick={() => { if (item.label === 'My Bookings') onViewBookings(); else if (item.label === 'Saved Properties') onViewSaved(); else onSetting(item.label); }} className="group flex items-center justify-between p-4 px-5 bg-white rounded-2xl shadow-sm border border-gray-100 hover:border-gray-200 active:bg-gray-50 transition-colors">
              <div className="flex items-center gap-4">
                <div className="text-gray-400 group-hover:text-primary transition-colors">
                  {item.icon}
                </div>
                <span className="font-bold text-gray-700 text-[15px]">{item.label}</span>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-gray-600 transition-colors" />
            </button>
          ))}
          
          <button onClick={onLogout} className="flex items-center justify-between p-4 px-5 bg-red-50/50 rounded-2xl mt-4 border border-red-100 hover:bg-red-50 active:scale-[0.98] transition-all">
             <div className="flex items-center gap-4 text-red-500">
                <LogOut className="w-5 h-5 relative top-[0.5px]" />
                <span className="font-bold text-[15px]">Logout</span>
             </div>
          </button>
        </div>
      </div>
    </div>
  );
}
