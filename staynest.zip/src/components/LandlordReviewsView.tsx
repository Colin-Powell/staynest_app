import { ChevronLeft, Star, ShieldCheck } from 'lucide-react';

export default function LandlordReviewsView({ onClose }: { onClose: () => void }) {
  const reviews = [
    { id: 1, name: 'Jane Wanjiru', date: '5 days ago', text: 'Great communication and professional service.', rating: 5, avatar: 'https://i.pravatar.cc/150?img=5' },
    { id: 2, type: 'suspended', name: 'Peter Kimani', date: '1 week ago', text: 'Quick response and well-maintained properties.', rating: 5, avatar: 'https://i.pravatar.cc/150?img=11' }
  ];

  return (
    <div className="flex-1 w-full bg-[#f8f9fa] flex flex-col h-full animate-in fade-in slide-in-from-right-4 duration-300 z-50 absolute inset-0">
      <div className="px-6 pt-12 pb-4 flex items-center sticky top-0 bg-[#f8f9fa] z-10">
        <button onClick={onClose} className="w-10 h-10 rounded-full border border-gray-100 flex items-center justify-center bg-white hover:bg-gray-50 flex-shrink-0 shadow-sm">
           <ChevronLeft className="w-5 h-5 text-gray-700" />
        </button>
        <h2 className="text-xl font-bold text-gray-900 flex-1 text-center pr-10">Landlord Reviews</h2>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-4 pb-32">
         {/* Landlord Header */}
         <div className="bg-white rounded-3xl p-4 shadow-sm border border-gray-100 mb-8 flex items-center gap-4">
            <div className="w-14 h-14 bg-green-50 rounded-2xl flex items-center justify-center text-green-500 border border-green-100 shrink-0">
               <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
               <h3 className="font-bold text-[16px] text-gray-900 leading-tight">GreenHomes Ltd.</h3>
               <div className="flex flex-wrap items-center gap-1.5 mt-1">
                  <Star className="w-4 h-4 text-orange-400 fill-orange-400" />
                  <span className="font-bold text-gray-900 text-sm">4.8</span>
                  <span className="font-semibold text-gray-500 text-xs">(120 reviews)</span>
               </div>
            </div>
         </div>

         <div className="flex flex-col gap-4">
            {reviews.map(r => (
               <div key={r.id} className="bg-white p-5 rounded-3xl shadow-sm border border-gray-100">
                  <div className="flex gap-3 mb-3">
                     <img src={r.avatar} alt={r.name} className="w-10 h-10 rounded-full object-cover shrink-0" />
                     <div className="flex-1">
                        <h4 className="font-bold text-sm text-gray-900">{r.name}</h4>
                        <p className="text-[11px] font-semibold text-gray-400">{r.date}</p>
                     </div>
                     {r.type === 'suspended' && <span className="bg-red-50 text-red-500 font-bold text-[10px] px-2 py-0.5 rounded-lg h-fit">Suspended</span>}
                  </div>
                  <p className="text-[14px] font-medium text-gray-600 leading-relaxed">{r.text}</p>
               </div>
            ))}
         </div>
      </div>
      
      <div className="absolute bottom-0 left-0 right-0 p-6 bg-white z-30 shadow-[0_-10px_20px_rgba(0,0,0,0.02)] pb-8">
         <button className="w-full h-14 bg-white border border-gray-200 text-gray-900 rounded-[1.2rem] font-bold text-[15px] hover:bg-gray-50 active:scale-[0.98] transition-transform">
           View All Reviews
         </button>
      </div>
    </div>
  );
}
