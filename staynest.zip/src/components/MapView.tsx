import { ChevronLeft, SlidersHorizontal, Star, Search } from 'lucide-react';
import { properties, formatPrice } from '../data';
import { MapContainer, TileLayer, Marker } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix for default leaflet icons not showing correctly in some bundlers
const createCustomIcon = (price: number) => {
  return L.divIcon({
    className: 'bg-transparent border-0',
    html: `<div class="bg-primary text-white font-bold text-xs px-3 py-2 rounded-xl shadow-[0_4px_12px_rgba(78,70,229,0.3)] relative -top-3 whitespace-nowrap">
            ${formatPrice(price)}
            <div class="absolute -bottom-1.5 left-1/2 -translate-x-1/2 border-[6px] border-transparent border-t-primary"></div>
          </div>`,
    iconSize: [60, 30],
    iconAnchor: [30, 30]
  });
};

export default function MapView({ onBack, onFilter, onSelectProperty }: { onBack: () => void, onFilter: () => void, onSelectProperty?: (id: string) => void }) {
  // Use a central location (e.g. NYC) based on our mock data coords
  const center = { lat: 40.7128, lng: -74.0060 };

  return (
    <div className="absolute inset-0 z-40 bg-slate-100 flex flex-col h-full rounded-[inherit] overflow-hidden">
      <MapContainer 
        center={[center.lat, center.lng]} 
        zoom={10} 
        style={{ height: '100%', width: '100%' }}
        zoomControl={false}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a>'
          url="https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png"
        />
        {properties.map(prop => prop.lat && prop.lng && (
          <Marker 
            key={prop.id} 
            position={[prop.lat, prop.lng]} 
            icon={createCustomIcon(prop.price)}
            eventHandlers={{ 
              click: () => onSelectProperty?.(prop.id) 
            }}
          />
        ))}
      </MapContainer>

      {/* Header Overlay */}
      <div className="absolute top-0 left-0 right-0 px-6 pt-12 pb-4 z-[400] pointer-events-none">
        <div className="flex gap-3 text-sm pointer-events-auto">
            <button 
              onClick={onBack}
              className="w-12 h-12 flex items-center justify-center bg-white rounded-full shadow-[0_4px_15px_rgba(0,0,0,0.05)] border border-gray-100 text-gray-900 active:scale-95 transition-transform shrink-0"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <div className="flex-1 bg-white rounded-full flex items-center px-5 shadow-[0_4px_15px_rgba(0,0,0,0.05)] border border-gray-100">
              <Search className="w-4 h-4 text-gray-400 mr-2" />
              <input
                type="text"
                className="bg-transparent border-none outline-none flex-1 font-bold text-[15px] text-gray-900 placeholder-gray-400 w-full"
                defaultValue="New York, USA"
                readOnly
              />
            </div>
            <button 
              onClick={onFilter}
              className="bg-white rounded-full w-12 flex items-center justify-center shadow-[0_4px_15px_rgba(0,0,0,0.05)] border border-gray-100 shrink-0 text-gray-700 active:scale-95 transition-transform"
            >
              <SlidersHorizontal className="w-5 h-5" />
            </button>
        </div>
      </div>

      <div className="absolute top-[100px] left-1/2 -translate-x-1/2 z-[400] pointer-events-auto">
         <button onClick={onBack} className="px-5 py-2.5 bg-gray-900/90 backdrop-blur-sm text-white rounded-full font-bold text-sm shadow-xl active:scale-95 transition-transform">
            Search this area
         </button>
      </div>
    </div>
  );
}
