import { ChevronLeft, MapPin } from 'lucide-react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';

export default function LocationView({ onClose, onNearbyPlaces, onGetDirections }: { onClose: () => void, onNearbyPlaces?: () => void, onGetDirections?: () => void }) {
  const position: [number, number] = [-1.2921, 36.8219]; // Nairobi, example limit

  return (
    <div className="flex-1 w-full bg-[#f8f9fa] flex flex-col h-full animate-in fade-in slide-in-from-right-4 duration-300 z-50 absolute inset-0">
      <div className="px-6 pt-12 pb-4 flex items-center sticky top-0 bg-[#f8f9fa] z-10 border-b border-gray-100 gap-3">
        <button onClick={onClose} className="text-gray-900 active:scale-95 transition-transform">
           <ChevronLeft className="w-6 h-6" />
        </button>
        <h2 className="text-xl font-bold text-gray-900">Location</h2>
      </div>
      
      <div className="flex-1 overflow-y-auto no-scrollbar relative flex flex-col relative">
        <div className="h-[250px] w-full z-0 relative z-0">
           <MapContainer center={position} zoom={13} zoomControl={false} className="w-full h-full z-0">
              <TileLayer url="https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png" />
              <Marker position={position}>
                 <Popup>Selected Property Location</Popup>
              </Marker>
           </MapContainer>
        </div>

        <div className="bg-white flex-1 p-6 z-10 shadow-[0_-8px_30px_rgba(0,0,0,0.05)] rounded-t-[2rem]">
           <h3 className="font-bold text-[16px] text-gray-900 mb-1">Kilimani, Nairobi</h3>
           <p className="text-[13px] font-semibold text-gray-400 mb-6">1.2 km from City Centre</p>

           <div className="flex justify-between items-center mb-4">
              <h4 className="text-[15px] font-bold text-gray-900">Nearby Places</h4>
              <button onClick={onNearbyPlaces} className="text-[13px] font-bold text-primary hover:text-primary/80">View Map</button>
           </div>
           
           <div className="flex flex-col gap-4">
              {[
                 { name: 'Yaya Centre', dist: '1.2 km' },
                 { name: 'Adams Arcade', dist: '1.5 km' },
                 { name: 'The Junction Mall', dist: '2.1 km' },
                 { name: 'Kilimani Police Station', dist: '1.8 km' },
                 { name: 'Kilimani Primary School', dist: '0.9 km' },
              ].map(place => (
                 <div key={place.name} className="flex justify-between items-center bg-slate-50 border border-gray-100 p-3.5 rounded-2xl">
                    <div className="flex items-center gap-3">
                       <div className="text-gray-400"><MapPin className="w-5 h-5" /></div>
                       <span className="font-semibold text-[14px] text-gray-700">{place.name}</span>
                    </div>
                    <span className="font-bold text-[13px] text-gray-500">{place.dist}</span>
                 </div>
              ))}
           </div>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 p-6 bg-white z-30 shadow-[0_-10px_20px_rgba(0,0,0,0.02)] pb-8">
         <button onClick={onGetDirections} className="w-full h-14 bg-primary text-white rounded-[1.2rem] font-bold text-[15px] shadow-[0_8px_20px_-6px_rgba(78,70,229,0.4)] active:scale-[0.98] transition-transform">
           Get Directions
         </button>
      </div>
    </div>
  );
}
