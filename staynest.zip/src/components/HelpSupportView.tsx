import { ChevronLeft, ChevronRight, LogOut } from 'lucide-react';

export default function HelpSupportView({ onBack }: { onBack: () => void }) {
  const MENU = [
    'FAQs',
    'Contact Support',
    'Safety Tips',
    'Report a Problem',
    'Terms & Conditions',
    'Privacy Policy'
  ];

  return (
    <div className="flex-1 w-full bg-slate-50 flex flex-col h-full animate-in fade-in slide-in-from-right-4 duration-300 z-50 absolute inset-0">
      <div className="px-6 py-6 pt-12 flex items-center sticky top-0 bg-white/80 backdrop-blur-md border-b border-gray-50 z-10 text-center">
         <button onClick={onBack} className="w-10 h-10 rounded-full border border-gray-100 flex items-center justify-center hover:bg-gray-50 flex-shrink-0 absolute left-6">
            <ChevronLeft className="w-6 h-6 text-gray-900" />
         </button>
         <h2 className="text-lg font-bold text-gray-900 flex-1">Help & Support</h2>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-6 flex flex-col gap-2 pb-12">
         {MENU.map((item, i) => (
           <button key={i} className="group flex items-center justify-between p-4 px-5 bg-white rounded-2xl shadow-sm border border-gray-100 hover:border-gray-200 active:bg-gray-50 transition-colors">
             <span className="font-bold text-gray-700 text-[15px]">{item}</span>
             <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-gray-600 transition-colors" />
           </button>
         ))}

         <div className="mt-8">
            <h3 className="text-[15px] font-bold text-gray-900 mb-4 ml-2">App Info</h3>
            <button className="flex items-center justify-between p-4 px-5 bg-white rounded-2xl shadow-sm border border-gray-100 hover:border-gray-200 active:bg-gray-50 transition-colors w-full">
               <span className="font-bold text-gray-700 text-[15px]">Version</span>
               <span className="font-bold text-gray-400 text-[14px]">v1.0.0</span>
            </button>
         </div>
      </div>
    </div>
  );
}
