import { ChevronRight, Home, Plus, Users, TrendingUp } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

export default function LandlordDashboardView({ onAddProperty, onAnalytics }: { onAddProperty: () => void, onAnalytics?: () => void }) {
  const data = [
    { name: 'Mon', views: 400 },
    { name: 'Tue', views: 300 },
    { name: 'Wed', views: 550 },
    { name: 'Thu', views: 450 },
    { name: 'Fri', views: 700 },
    { name: 'Sat', views: 600 },
    { name: 'Sun', views: 800 },
  ];

  return (
    <div className="flex-1 overflow-y-auto w-full bg-[#f8f9fa] no-scrollbar pb-24 animate-in fade-in zoom-in-95 duration-200">
      <div className="px-6 pt-12 pb-4 bg-[#f8f9fa] sticky top-0 z-10 flex justify-between items-center">
         <div>
            <h1 className="text-xl font-bold text-gray-900 leading-tight">Dashboard</h1>
         </div>
      </div>

      <div className="px-6 py-2">
        <div className="grid grid-cols-2 gap-4 mb-6">
           <div className="bg-white p-4 rounded-[1.2rem] shadow-sm hover:shadow-[0_8px_30px_rgba(0,0,0,0.06)] transition-shadow">
              <span className="text-[11px] font-bold text-gray-400 mb-1 block">Total Views</span>
              <div className="flex justify-between items-end">
                <span className="text-2xl font-bold text-gray-900">1,234</span>
                <span className="text-[10px] font-bold text-green-500 mb-1.5 flex items-center gap-0.5"><TrendingUp className="w-3 h-3" /> +12%</span>
              </div>
           </div>
           <div className="bg-white p-4 rounded-[1.2rem] shadow-sm hover:shadow-[0_8px_30px_rgba(0,0,0,0.06)] transition-shadow">
              <span className="text-[11px] font-bold text-gray-400 mb-1 block">Inquiries</span>
              <div className="flex justify-between items-end">
                <span className="text-2xl font-bold text-gray-900">87</span>
                <span className="text-[10px] font-bold text-green-500 mb-1.5 flex items-center gap-0.5"><TrendingUp className="w-3 h-3" /> +8%</span>
              </div>
           </div>
           <div className="bg-white p-4 rounded-[1.2rem] shadow-sm hover:shadow-[0_8px_30px_rgba(0,0,0,0.06)] transition-shadow">
              <span className="text-[11px] font-bold text-gray-400 mb-1 block">Bookings</span>
              <div className="flex justify-between items-end">
                <span className="text-2xl font-bold text-gray-900">34</span>
                <span className="text-[10px] font-bold text-green-500 mb-1.5 flex items-center gap-0.5"><TrendingUp className="w-3 h-3" /> +15%</span>
              </div>
           </div>
           <div className="bg-white p-4 rounded-[1.2rem] shadow-sm hover:shadow-[0_8px_30px_rgba(0,0,0,0.06)] transition-shadow">
              <span className="text-[11px] font-bold text-gray-400 mb-1 block">Total Revenue</span>
              <div className="flex justify-between items-end">
                <span className="text-2xl font-bold text-gray-900">85k</span>
                <span className="text-[10px] font-bold text-green-500 mb-1.5 flex items-center gap-0.5"><TrendingUp className="w-3 h-3" /> +16%</span>
              </div>
           </div>
        </div>

        <div className="bg-white rounded-[1.5rem] p-4 shadow-sm hover:shadow-[0_8px_30px_rgba(0,0,0,0.06)] transition-shadow mb-8 relative border border-white">
           <div className="flex justify-between items-center mb-6">
             <div>
               <h3 className="font-bold text-gray-900 text-sm">Analytics</h3>
               <p className="text-xs font-semibold text-gray-400">Views</p>
             </div>
             <div className="flex items-center gap-1">
               <span className="text-2xl font-bold text-gray-900">3,458</span>
               <span className="text-[10px] font-bold text-green-500 mb-1 flex items-center gap-0.5"><TrendingUp className="w-3 h-3" /> +18%</span>
             </div>
           </div>
           
           <div className="h-[120px] w-full ml-[-1rem]">
             <ResponsiveContainer width="100%" height="100%">
               <AreaChart data={data}>
                 <defs>
                   <linearGradient id="colorViews" x1="0" y1="0" x2="0" y2="1">
                     <stop offset="5%" stopColor="#4F46E5" stopOpacity={0.3}/>
                     <stop offset="95%" stopColor="#4F46E5" stopOpacity={0}/>
                   </linearGradient>
                 </defs>
                 <XAxis dataKey="name" hide />
                 <YAxis hide />
                 <Tooltip contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 4px 15px rgba(0,0,0,0.1)', fontSize: '12px', fontWeight: 'bold' }} />
                 <Area type="monotone" dataKey="views" stroke="#4F46E5" strokeWidth={3} fillOpacity={1} fill="url(#colorViews)" />
               </AreaChart>
             </ResponsiveContainer>
           </div>
        </div>

        <div className="flex justify-between items-center mb-4">
           <h2 className="text-[17px] font-bold text-gray-900">Recent Inquiries</h2>
           <button className="text-[13px] font-bold text-primary hover:text-primary/80">See all</button>
        </div>

        <div className="flex flex-col gap-4 mb-24">
           {/* Inquiries */}
           {[1,2,3].map(i => (
             <div key={i} className="flex gap-4 items-center bg-white p-3.5 rounded-[1.2rem] shadow-sm hover:shadow-[0_8px_30px_rgba(0,0,0,0.06)] transition-shadow">
                <img src={`https://i.pravatar.cc/150?img=${i+20}`} alt="avatar" className="w-12 h-12 rounded-full object-cover shrink-0" />
                <div className="flex-1 min-w-0 pr-2">
                   <div className="flex justify-between items-center mb-1">
                      <h3 className="font-bold text-gray-900 text-sm truncate">User {i}</h3>
                      <span className="text-[11px] font-semibold text-gray-400">{i}m</span>
                   </div>
                   <p className="text-[13px] font-medium text-gray-500 truncate">Is it available?</p>
                </div>
             </div>
           ))}
        </div>
      </div>

      <div className="fixed sm:absolute bottom-[90px] right-6 z-20">
         <button onClick={onAddProperty} className="w-14 h-14 bg-primary text-white rounded-full flex items-center justify-center shadow-[0_8px_20px_-6px_rgba(78,70,229,0.5)] active:scale-95 transition-transform">
            <Plus className="w-6 h-6" />
         </button>
      </div>

    </div>
  );
}
