import { ChevronLeft, GraduationCap, Hospital, ShoppingCart, Bus } from 'lucide-react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import { useState } from 'react';

export default function NearbyServicesView({ onClose }: { onClose: () => void }) {
  const [selected, setSelected] = useState('Universities');
  const position: [number, number] = [-1.2921, 36.8219];

  return (
    <div className="flex-1 w-full bg-[#f8f9fa] flex flex-col h-full animate-in fade-in slide-in-from-right-4 duration-300 z-50 absolute inset-0">
      <div className="px-6 pt-12 pb-4 flex items-center sticky top-0 bg-[#f8f9fa] z-10">
        <button onClick={onClose} className="w-10 h-10 rounded-full border border-gray-100 flex items-center justify-center bg-white hover:bg-gray-50 flex-shrink-0 shadow-sm">
           <ChevronLeft className="w-5 h-5 text-gray-700" />
        </button>
        <h2 className="text-xl font-bold text-gray-900 flex-1 text-center pr-10">Nearby Services</h2>
      </div>

      <div className="px-6 py-2 flex gap-4 overflow-x-auto no-scrollbar bg-[#f8f9fa] sticky top-[73px] z-10 pb-6">
        {[
          { id: 'Universities', icon: <GraduationCap className="w-5 h-5" /> },
          { id: 'Hospitals', icon: <Hospital className="w-5 h-5" /> },
          { id: 'Supermarkets', icon: <ShoppingCart className="w-5 h-5" /> },
          { id: 'Bus Stops', icon: <Bus className="w-5 h-5" /> }
        ].map(cat => (
          <button 
            key={cat.id}
            onClick={() => setSelected(cat.id)}
            className={`flex flex-col items-center gap-2 min-w-[70px] shrink-0 transition-opacity ${selected === cat.id ? 'opacity-100' : 'opacity-40 grayscale'}`}
          >
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shadow-sm ${selected === cat.id ? 'bg-primary text-white shadow-primary/30' : 'bg-white text-gray-500 border border-gray-100 hover:bg-gray-50'}`}>
               {cat.icon}
            </div>
            <span className="text-[11px] font-bold text-gray-900">{cat.id}</span>
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar pb-32">
        <div className="h-[250px] w-full z-0 relative">
           <MapContainer center={position} zoom={13} zoomControl={false} className="w-full h-full z-0">
              <TileLayer url="https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png" />
              <Marker position={position} />
           </MapContainer>
        </div>

        <div className="bg-white flex-1 p-6 z-10 shadow-[0_-8px_30px_rgba(0,0,0,0.05)] rounded-t-[2rem] relative -mt-4">
           <h4 className="text-[15px] font-bold text-gray-900 mb-4">Nearby Places</h4>
           
           <div className="flex flex-col gap-4">
              {[
                 { name: 'Yaya Centre', dist: '1.2 km' },
                 { name: 'Aga Khan Hospital', dist: '3.4 km' },
                 { name: 'Carrefour Junction', dist: '1.6 km' },
                 { name: 'Prestige Plaza', dist: '1.5 km' },
                 { name: 'Kilimani Police Station', dist: '1.3 km' },
              ].map(place => (
                 <div key={place.name} className="flex justify-between items-center bg-slate-50 border border-gray-100 p-3.5 rounded-2xl">
                    <div className="flex items-center gap-3">
                       <div className="text-gray-400"><ShoppingCart className="w-5 h-5" /></div>
                       <span className="font-semibold text-[14px] text-gray-700">{place.name}</span>
                    </div>
                    <span className="font-bold text-[13px] text-gray-500">{place.dist}</span>
                 </div>
              ))}
           </div>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 p-6 bg-white z-30 shadow-[0_-10px_20px_rgba(0,0,0,0.02)] pb-8">
         <button className="w-full h-14 bg-primary text-white rounded-[1.2rem] font-bold text-[15px] shadow-[0_8px_20px_-6px_rgba(78,70,229,0.4)] active:scale-[0.98] transition-transform">
           View on Map
         </button>
      </div>
    </div>
  );
}
