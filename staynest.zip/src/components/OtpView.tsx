import { useState, useRef } from 'react';
import { ChevronLeft } from 'lucide-react';

export default function OtpView({ onVerify, onBack }: { onVerify: () => void, onBack: () => void }) {
  const [code, setCode] = useState(['6', '2', '4', '1', '0', '8']);

  return (
    <div className="flex-1 w-full bg-white flex flex-col h-full animate-in fade-in zoom-in-95 duration-300">
      <div className="px-6 py-6 flex items-center">
        <button onClick={onBack} className="w-10 h-10 rounded-full border border-gray-100 flex items-center justify-center hover:bg-gray-50">
           <ChevronLeft className="w-6 h-6 text-gray-900" />
        </button>
      </div>

      <div className="flex-1 px-6 py-4 flex flex-col">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Verify Your Phone</h1>
        <p className="text-gray-500 mb-8 font-medium text-[15px] leading-relaxed">
          Enter the 6-digit code sent to<br/>
          <span className="font-bold text-gray-900">+254 712 545 678</span>
        </p>
        
        <div className="flex justify-between gap-1.5 sm:gap-2 mb-10 text-center px-1">
           {code.map((digit, i) => (
             <input 
               key={i}
               type="text"
               maxLength={1}
               defaultValue={digit}
               className="w-11 sm:w-12 h-14 bg-gray-50 border border-gray-200 rounded-xl text-center text-xl font-bold text-gray-900 focus:border-primary/50 focus:ring-2 focus:ring-primary/10 transition-all outline-none"
             />
           ))}
        </div>

        <div className="flex justify-center mb-10 text-[13px] font-semibold text-gray-500">
           Resend code in <span className="font-bold text-gray-900 ml-1">00:30</span>
        </div>
        
        <div className="mt-auto pb-8">
           <button 
             onClick={onVerify}
             className="w-full h-14 bg-primary text-white rounded-2xl font-bold text-[15px] shadow-lg shadow-primary/30 active:scale-[0.98] transition-transform"
           >
             Verify
           </button>
        </div>
      </div>
    </div>
  );
}
