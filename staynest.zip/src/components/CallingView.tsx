import { Mic, PhoneOff, Volume2, Video } from 'lucide-react';

export default function CallingView({ name, avatar, onEndCall }: { name: string, avatar: string, onEndCall: () => void }) {
  return (
    <div className="flex-1 w-full bg-slate-900 flex flex-col h-full animate-in fade-in slide-in-from-bottom-5 duration-300 z-50 absolute inset-0 py-12">
      <div className="flex-1 flex flex-col items-center justify-center p-6 mt-12">
         <p className="text-white/60 font-medium text-[15px] mb-2">Calling...</p>
         <h2 className="text-3xl font-bold text-white mb-10">{name}</h2>
         
         <div className="relative">
            <div className="absolute inset-0 bg-primary/20 rounded-full animate-ping"></div>
            <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-slate-800 relative z-10 shadow-xl">
               <img src={avatar} alt={name} className="w-full h-full object-cover" />
            </div>
         </div>
      </div>

      <div className="w-full pb-16 px-8 flex justify-center items-center gap-6 z-10">
         <div className="flex flex-col items-center gap-2">
           <button className="w-14 h-14 rounded-full bg-white/10 text-white flex items-center justify-center hover:bg-white/20 transition-colors backdrop-blur-sm">
             <Mic className="w-6 h-6" />
           </button>
           <span className="text-[11px] font-medium text-white/60">Mute</span>
         </div>
         
         <div className="flex flex-col items-center gap-2 -mt-4">
           <button 
             onClick={onEndCall}
             className="w-20 h-20 rounded-full bg-red-500 text-white flex items-center justify-center hover:bg-red-600 transition-colors shadow-lg shadow-red-500/20 active:scale-95"
           >
             <PhoneOff className="w-8 h-8" />
           </button>
         </div>

         <div className="flex flex-col items-center gap-2">
           <button className="w-14 h-14 rounded-full bg-white/10 text-white flex items-center justify-center hover:bg-white/20 transition-colors backdrop-blur-sm">
             <Volume2 className="w-6 h-6" />
           </button>
           <span className="text-[11px] font-medium text-white/60">Speaker</span>
         </div>
      </div>
    </div>
  );
}
