import { ChevronLeft, User, Home, ShieldCheck } from 'lucide-react';
import { useState } from 'react';

export default function RoleSelectionView({ onBack, onSelect }: { onBack: () => void, onSelect: (role: 'tenant' | 'landlord' | 'admin') => void }) {
  const [selected, setSelected] = useState<'tenant' | 'landlord' | 'admin' | null>(null);

  return (
    <div className="flex-1 w-full bg-[#f8f9fa] flex flex-col items-center h-full animate-in fade-in zoom-in-95 duration-300 relative">
      <div className="w-full px-6 pt-12 pb-4 flex items-center sticky top-0 z-10">
        <button onClick={onBack} className="w-10 h-10 rounded-full bg-white shadow-sm border border-gray-100 flex items-center justify-center hover:bg-gray-50 flex-shrink-0">
           <ChevronLeft className="w-5 h-5 text-gray-700" />
        </button>
      </div>

      <div className="flex-1 w-full px-6 flex flex-col pt-6 pb-28">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Choose Your Role</h1>
        <p className="text-gray-500 font-medium text-sm mb-10">
          Select the option that best<br/>describes you.
        </p>

        <div className="flex flex-col gap-4">
          <button 
            onClick={() => setSelected('tenant')}
            className={`w-full bg-white rounded-3xl p-5 flex items-center gap-5 transition-all shadow-sm border ${selected === 'tenant' ? 'border-primary ring-2 ring-primary/10' : 'border-gray-100'}`}
          >
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 ${selected === 'tenant' ? 'bg-primary/10 text-primary' : 'bg-gray-50 text-gray-400'}`}>
              <User className="w-6 h-6" />
            </div>
            <div className="flex flex-col items-start gap-0.5">
              <span className="font-bold text-gray-900 text-[16px]">I'm looking for a Place</span>
              <span className="text-sm font-semibold text-gray-400">(Tenant)</span>
            </div>
          </button>

          <button 
            onClick={() => setSelected('landlord')}
            className={`w-full bg-white rounded-3xl p-5 flex items-center gap-5 transition-all shadow-sm border ${selected === 'landlord' ? 'border-primary ring-2 ring-primary/10' : 'border-gray-100'}`}
          >
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 ${selected === 'landlord' ? 'bg-primary/10 text-primary' : 'bg-gray-50 text-gray-400'}`}>
              <Home className="w-6 h-6" />
            </div>
            <div className="flex flex-col items-start gap-0.5">
              <span className="font-bold text-gray-900 text-[16px]">I'm a Landlord / Agent</span>
              <span className="text-sm font-semibold text-gray-400">(Landlord / Agent)</span>
            </div>
          </button>

          <button 
            onClick={() => setSelected('admin')}
            className={`w-full bg-white rounded-3xl p-5 flex items-center gap-5 transition-all shadow-sm border ${selected === 'admin' ? 'border-primary ring-2 ring-primary/10' : 'border-gray-100'}`}
          >
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 ${selected === 'admin' ? 'bg-primary/10 text-primary' : 'bg-gray-50 text-gray-400'}`}>
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div className="flex flex-col items-start gap-0.5">
              <span className="font-bold text-gray-900 text-[16px]">I'm an Administrator</span>
            </div>
          </button>
        </div>

        <div className="mt-auto pt-6">
          <button 
            disabled={!selected}
            onClick={() => selected && onSelect(selected)}
            className="w-full h-14 bg-primary text-white rounded-[1.2rem] font-bold text-[15px] shadow-[0_8px_30px_rgba(78,70,229,0.3)] disabled:opacity-50 disabled:shadow-none active:scale-[0.98] transition-transform"
          >
            Continue
          </button>
        </div>
      </div>
    </div>
  );
}
