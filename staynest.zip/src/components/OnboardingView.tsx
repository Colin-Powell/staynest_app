import { useState } from 'react';

const SLIDES = [
  {
    title: 'Find Your\nPerfect Place',
    desc: 'Discover verified rooms, apartments and houses near you.',
    img: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&q=80&w=800',
  },
  {
    title: 'Verified Homes,\nTrusted Landlords',
    desc: 'We verify every landlord and listing to keep you safe from fraud.',
    img: 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&q=80&w=800',
  },
  {
    title: 'Easy Search,\nSmart Choice',
    desc: 'Search, compare and book homes that fit your budget.',
    img: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=800',
  }
];

export default function OnboardingView({ onFinish }: { onFinish: () => void }) {
  const [step, setStep] = useState(0);

  const slide = SLIDES[step];

  const handleNext = () => {
    if (step < SLIDES.length - 1) {
      setStep(step + 1);
    } else {
      onFinish();
    }
  };

  return (
    <div className="flex-1 w-full bg-white flex flex-col items-center animate-in fade-in zoom-in-95 duration-300 relative h-full">
      <div className="flex-1 flex flex-col w-full h-full p-6 pt-12 pb-10">
        
        <div className="flex-1 flex flex-col justify-center">
            <h1 className="text-3xl font-bold text-gray-900 mb-4 whitespace-pre-line leading-tight">
              {slide.title}
            </h1>
            <p className="text-gray-500 mb-10 text-[15px] leading-relaxed pr-8">
              {slide.desc}
            </p>
            
            <div className="relative w-full aspect-square rounded-[2rem] overflow-hidden shadow-sm border border-gray-100 flex items-center justify-center bg-slate-50 mb-8 p-4">
               {/* Using placeholder images as exact illustrations are not available */}
               <img src={slide.img} alt="illustration" className="w-full h-full object-cover rounded-2xl shadow-sm" />
            </div>
        </div>

        <div className="w-full flex-col flex gap-6 items-center shrink-0">
          <div className="flex gap-2 mb-2">
            {SLIDES.map((_, i) => (
              <div 
                key={i} 
                className={`h-2 rounded-full transition-all duration-300 ${i === step ? 'w-6 bg-primary' : 'w-2 bg-gray-200'}`}
              />
            ))}
          </div>

          <button 
            onClick={handleNext}
            className="w-full h-14 bg-primary text-white rounded-2xl font-bold text-[15px] shadow-lg shadow-primary/30 active:scale-[0.98] transition-transform"
          >
            {step === 0 ? 'Get Started' : 'Next'}
          </button>
          
          <button 
            onClick={onFinish}
            className="text-gray-400 font-semibold text-[15px] hover:text-gray-600 transition-colors"
          >
            Skip
          </button>
        </div>
      </div>
    </div>
  );
}
