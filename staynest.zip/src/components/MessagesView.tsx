import { Search as SearchIcon } from 'lucide-react';

const chats = [
  { id: 1, name: 'John Kamau', avatar: 'https://i.pravatar.cc/150?img=11', msg: 'Hi, is the room still available?', time: '2m', unread: 2, online: true },
  { id: 2, name: 'Mary Wanjiku', avatar: 'https://i.pravatar.cc/150?img=32', msg: 'Thanks for the info', time: '1h', unread: 0, online: false },
  { id: 3, name: 'David Ochieng', avatar: 'https://i.pravatar.cc/150?img=68', msg: 'Let me check and get back to you', time: '3h', unread: 0, online: true },
  { id: 4, name: 'Landlord Support', avatar: 'https://i.pravatar.cc/150?img=12', msg: 'Your booking is confirmed. View details...', time: '1d', unread: 0, online: false },
];

export default function MessagesView({ onSelectChat }: { onSelectChat: (id: number, name: string, avatar: string) => void }) {
  return (
    <div className="flex-1 overflow-y-auto w-full bg-white no-scrollbar pb-24 animate-in fade-in zoom-in-95 duration-200">
      <div className="px-6 pt-12 pb-4 sticky top-0 bg-white/80 backdrop-blur-md z-10 border-b border-gray-50">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold text-gray-900">Messages</h1>
            <button className="w-10 h-10 rounded-full border border-gray-100 flex items-center justify-center text-gray-900 hover:bg-gray-50">
              <SearchIcon className="w-5 h-5" />
            </button>
          </div>
      </div>

      <div className="px-6 py-4 flex flex-col gap-6 pb-28">
        {chats.map((chat, idx) => (
          <div key={chat.id}>
              <div 
                 className="flex gap-4 items-center cursor-pointer group"
                 onClick={() => onSelectChat(chat.id, chat.name, chat.avatar)}
              >
                <div className="relative shrink-0">
                  <img src={chat.avatar} alt={chat.name} className="w-14 h-14 rounded-full object-cover shadow-sm" />
                  {chat.online && (
                    <div className="absolute bottom-0 right-0 w-3.5 h-3.5 bg-green-500 border-[2.5px] border-white rounded-full"></div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-center mb-1">
                    <h3 className="font-bold text-gray-900 truncate text-[15px] group-hover:text-primary transition-colors">{chat.name}</h3>
                    <span className={`text-xs font-semibold ${chat.unread > 0 ? 'text-primary' : 'text-gray-400'}`}>{chat.time}</span>
                  </div>
                  <div className="flex justify-between items-center pr-1">
                    <p className={`text-sm truncate pr-2 ${chat.unread > 0 ? 'text-gray-900 font-semibold' : 'text-gray-500 font-medium'}`}>{chat.msg}</p>
                    {chat.unread > 0 && (
                      <div className="w-5 h-5 bg-primary rounded-full flex items-center justify-center text-[10px] font-bold text-white shrink-0 shadow-sm shadow-primary/30">
                        {chat.unread}
                      </div>
                    )}
                  </div>
                </div>
              </div>
              {idx < chats.length - 1 && <div className="ml-18 h-[1px] bg-gray-50 mt-6 box-border"></div>}
          </div>
        ))}
      </div>
    </div>
  );
}
