import { ChevronLeft, Star } from 'lucide-react';

export default function ReviewsView({ onBack, onWriteReview, onLandlordReviews }: { onBack: () => void, onWriteReview?: () => void, onLandlordReviews?: () => void }) {
  return (
    <div className="flex-1 w-full bg-slate-50 flex flex-col h-full animate-in fade-in slide-in-from-right-4 duration-300 z-50 absolute inset-0">
      <div className="px-6 py-6 pt-12 flex items-center sticky top-0 bg-white/80 backdrop-blur-md border-b border-gray-50 z-10 text-center">
         <button onClick={onBack} className="w-10 h-10 rounded-full border border-gray-100 flex items-center justify-center hover:bg-gray-50 flex-shrink-0 absolute left-6">
            <ChevronLeft className="w-6 h-6 text-gray-900" />
         </button>
         <h2 className="text-lg font-bold text-gray-900 flex-1">Reviews</h2>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-8 pb-12">
         {/* Overall Rating Header */}
         <div className="flex items-center justify-between mb-8">
            <div className="flex flex-col">
               <span className="text-sm font-bold text-gray-500 mb-1">Overall Rating</span>
               <span className="text-4xl font-bold text-gray-900 mb-2">4.8</span>
               <div className="flex text-orange-400 mb-2">
                  <Star className="w-4 h-4 fill-current" />
                  <Star className="w-4 h-4 fill-current" />
                  <Star className="w-4 h-4 fill-current" />
                  <Star className="w-4 h-4 fill-current" />
                  <Star className="w-4 h-4 fill-current" />
               </div>
               <span className="text-xs font-semibold text-gray-400">(100 Reviews)</span>
            </div>
            
            {/* Rating Bars */}
            <div className="flex flex-col gap-2 w-32 border-l border-gray-200 pl-4">
               {[
                 { star: 5, pct: 'w-full' },
                 { star: 4, pct: 'w-3/4' },
                 { star: 3, pct: 'w-1/4' },
                 { star: 2, pct: 'w-1/12' },
                 { star: 1, pct: 'w-0' },
               ].map((bar, i) => (
                  <div key={i} className="flex items-center gap-2">
                     <span className="text-xs font-bold text-gray-500 w-2 text-right">{bar.star}</span>
                     <div className="h-1.5 flex-1 bg-gray-200 rounded-full overflow-hidden">
                        <div className={`h-full bg-orange-400 rounded-full ${bar.pct}`}></div>
                     </div>
                  </div>
               ))}
            </div>
         </div>

         <div className="w-full h-[1px] bg-gray-200 mb-6"></div>

         <div className="flex gap-3 mb-8">
            <button onClick={onWriteReview} className="flex-1 py-3.5 bg-primary text-white rounded-2xl font-bold text-[14px] shadow-[0_8px_20px_-6px_rgba(78,70,229,0.4)] transition-transform active:scale-95">
               Write a Review
            </button>
            <button onClick={onLandlordReviews} className="flex-1 py-3.5 bg-white border border-gray-200 text-gray-900 rounded-2xl font-bold text-[14px] shadow-sm hover:bg-gray-50 transition-colors active:scale-95">
               Landlord Reviews
            </button>
         </div>

         {/* Review List */}
         <div className="flex flex-col gap-6">
            {[1, 2, 3].map((item) => (
              <div key={item} className="flex flex-col">
                 <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-3">
                       <img src={`https://i.pravatar.cc/150?img=${item + 30}`} alt="Avatar" className="w-10 h-10 rounded-full object-cover" />
                       <div>
                          <h4 className="font-bold text-gray-900 text-sm mb-0.5">Mary Wanjiku</h4>
                          <span className="text-xs font-semibold text-gray-400">May 15, 2024</span>
                       </div>
                    </div>
                    <div className="flex text-orange-400">
                        <Star className="w-3.5 h-3.5 fill-current" />
                        <span className="text-xs font-bold text-gray-900 ml-1">4.5</span>
                    </div>
                 </div>
                 <p className="text-[14px] font-medium text-gray-600 leading-relaxed">
                    Great landlord! The place is clean and secure. Very responsive to maintenance requests. Highly recommended.
                 </p>
              </div>
            ))}
         </div>
      </div>
    </div>
  );
}
