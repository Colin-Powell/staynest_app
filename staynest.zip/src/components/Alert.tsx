import { CheckCircle2, AlertTriangle, AlertCircle, Info } from 'lucide-react';
import { useEffect, useState } from 'react';

export type AlertType = 'success' | 'error' | 'warning' | 'info';

interface AlertProps {
  type: AlertType;
  message: string;
  onClose: () => void;
}

export default function Alert({ type, message, onClose }: AlertProps) {
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const t1 = setTimeout(() => {
      setVisible(false);
    }, 4000);
    const t2 = setTimeout(() => {
      onClose();
    }, 4300);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [onClose]);

  const getStyle = () => {
    switch(type) {
      case 'success': return 'bg-green-50/90 border-green-200 text-green-800';
      case 'error': return 'bg-red-50/90 border-red-200 text-red-800';
      case 'warning': return 'bg-amber-50/90 border-amber-200 text-amber-800';
      case 'info': return 'bg-blue-50/90 border-blue-200 text-blue-800';
    }
  };

  const getIcon = () => {
    switch(type) {
      case 'success': return <CheckCircle2 className="w-5 h-5 text-green-500" />;
      case 'error': return <AlertCircle className="w-5 h-5 text-red-500" />;
      case 'warning': return <AlertTriangle className="w-5 h-5 text-amber-500" />;
      case 'info': return <Info className="w-5 h-5 text-blue-500" />;
    }
  };

  return (
    <div className={`fixed top-8 left-1/2 -translate-x-1/2 z-[100] w-[90%] max-w-[360px] p-4 rounded-2xl border shadow-lg backdrop-blur-md flex items-center gap-3 transition-all duration-500 ease-out ${getStyle()} ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-8'}`}>
       {getIcon()}
       <p className="text-[13px] font-bold flex-1 tracking-tight">{message}</p>
    </div>
  );
}
