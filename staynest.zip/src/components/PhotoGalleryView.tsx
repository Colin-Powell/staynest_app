import { ChevronLeft } from 'lucide-react';
import { useState } from 'react';

export default function PhotoGalleryView({ onClose }: { onClose: () => void }) {
  const [tab, setTab] = useState('Photos');

  // placeholder images
  const photos = [
    'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&q=80&w=400',
    'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&q=80&w=400',
    'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&q=80&w=400',
    'https://images.unsplash.com/photo-1493809842364-78817add7ffb?auto=format&fit=crop&q=80&w=400',
    'https://images.unsplash.com/photo-1502672260266-1c1ea525fe56?auto=format&fit=crop&q=80&w=400',
    'https://images.unsplash.com/photo-1484154218962-a197022b5858?auto=format&fit=crop&q=80&w=400'
  ];

  return (
    <div className="flex-1 w-full bg-[#f8f9fa] flex flex-col h-full animate-in fade-in slide-in-from-right-4 duration-300 z-50 absolute inset-0">
      <div className="px-6 pt-12 pb-4 flex items-center sticky top-0 bg-[#f8f9fa] z-10 gap-3">
        <button onClick={onClose} className="text-gray-900 active:scale-95 transition-transform">
           <ChevronLeft className="w-6 h-6" />
        </button>
        <h2 className="text-xl font-bold text-gray-900">Photo Gallery</h2>
      </div>

      <div className="px-6 py-2 flex gap-2 overflow-x-auto no-scrollbar bg-[#f8f9fa] sticky top-[73px] z-10 pb-4">
        {['Photos', 'Videos', '360°', 'Floor Plan'].map(t => (
          <button 
            key={t}
            onClick={() => setTab(t)}
            className={`px-5 py-2.5 rounded-[1.2rem] font-bold text-sm whitespace-nowrap transition-colors bg-white ${tab === t ? 'bg-primary text-white shadow-md' : 'text-gray-500 border border-gray-200'}`}
          >
            {t}
          </button>
        ))}
      </div>
      
      <div className="flex-1 overflow-y-auto px-6 py-4 pb-28">
         <div className="grid grid-cols-2 gap-4">
            {photos.map((url, i) => (
               <div key={i} className={`rounded-[1.2rem] overflow-hidden shadow-sm ${i === 0 ? 'col-span-2 h-[240px]' : 'h-[160px]'}`}>
                  <img src={url} alt={`Gallery ${i}`} className="w-full h-full object-cover" />
               </div>
            ))}
         </div>
      </div>
    </div>
  );
}
