import { ChevronLeft, Star } from 'lucide-react';
import { useState } from 'react';

export default function WriteReviewView({ onClose, onSubmit }: { onClose: () => void, onSubmit: () => void }) {
  const [rating, setRating] = useState(0);

  return (
    <div className="flex-1 w-full bg-[#f8f9fa] flex flex-col h-full animate-in fade-in slide-in-from-right-4 duration-300 z-50 absolute inset-0">
      <div className="px-6 pt-12 pb-4 flex items-center sticky top-0 bg-[#f8f9fa] z-10">
        <button onClick={onClose} className="w-10 h-10 rounded-full border border-gray-100 flex items-center justify-center bg-white hover:bg-gray-50 flex-shrink-0 shadow-sm">
           <ChevronLeft className="w-5 h-5 text-gray-700" />
        </button>
        <h2 className="text-xl font-bold text-gray-900 flex-1 text-center pr-10">Write a Review</h2>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-4 pb-32">
        <h3 className="text-[15px] font-bold text-gray-900 mb-4">Overall Rating</h3>
        <div className="flex gap-2 mb-8 items-center justify-center py-6 bg-white rounded-3xl border border-gray-100 shadow-sm">
           {[1, 2, 3, 4, 5].map(star => (
              <button key={star} onClick={() => setRating(star)}>
                 <Star className={`w-10 h-10 transition-colors ${rating >= star ? 'text-orange-400 fill-orange-400' : 'text-gray-200'}`} />
              </button>
           ))}
        </div>

        <h3 className="text-[15px] font-bold text-gray-900 mb-4">Your Review</h3>
        <textarea 
          placeholder="Share your experience..."
          className="w-full bg-white border border-gray-100 rounded-3xl p-5 min-h-[150px] outline-none mb-8 shadow-sm text-sm font-medium text-gray-700 placeholder-gray-400 resize-none"
        ></textarea>

        <h3 className="text-[15px] font-bold text-gray-900 mb-4">Add Photos</h3>
        <div className="flex gap-4 overflow-x-auto no-scrollbar pb-2">
           {[1, 2, 3].map(i => (
             <div key={i} className="w-24 h-24 rounded-[1.2rem] border-2 border-dashed border-gray-200 flex items-center justify-center text-gray-400 shrink-0 bg-white">
                <span className="text-2xl">+</span>
             </div>
           ))}
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 p-6 bg-white z-30 shadow-[0_-10px_20px_rgba(0,0,0,0.02)] pb-8">
         <button onClick={onSubmit} className="w-full h-14 bg-primary text-white rounded-[1.2rem] font-bold text-[15px] shadow-[0_8px_20px_-6px_rgba(78,70,229,0.4)] active:scale-[0.98] transition-transform">
           Submit Review
         </button>
      </div>
    </div>
  );
}
