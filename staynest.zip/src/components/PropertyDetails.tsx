import { Bookmark, CircleParking, ChevronLeft, ChevronRight, Droplets, Home, MapPin, Maximize, ShieldCheck, Sofa, Star, Wifi } from 'lucide-react';
import { formatPrice, properties } from '../data';
import { Property } from '../types';

const getAmenityIcon = (name: string) => {
  switch (name) {
    case 'wifi': return <Wifi className="w-5 h-5 text-primary" />;
    case 'water': return <Droplets className="w-5 h-5 text-primary" />;
    case 'parking': return <CircleParking className="w-5 h-5 text-primary" />;
    case 'security': return <ShieldCheck className="w-5 h-5 text-primary" />;
    default: return null;
  }
};

export default function PropertyDetails({ id, onBack, onBook, onMessage, onViewAmenities, onViewGallery, onViewLocation, onViewLandlord }: { id: string; onBack: () => void, onBook: () => void, onMessage: () => void, onViewAmenities?: () => void, onViewGallery?: () => void, onViewLocation?: () => void, onViewLandlord?: () => void }) {
  const property: Property | undefined = properties.find(p => p.id === id);

  if (!property) return null;

  return (
    <div className="flex-1 overflow-y-auto w-full bg-[#f8f9fa] no-scrollbar relative flex flex-col h-full z-10 animate-in fade-in zoom-in-95 duration-200">
      
      {/* Absolute top actions layer */}
      <div className="absolute top-12 left-0 right-0 px-6 flex justify-between items-center z-20">
        <button 
          onClick={onBack}
          className="w-10 h-10 bg-white shadow-md rounded-full flex items-center justify-center text-gray-900"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
        <div className="bg-white/90 backdrop-blur-sm shadow-md rounded-full px-3 h-9 flex items-center gap-1.5 text-green-600 font-bold text-xs border border-white/20">
          <ShieldCheck className="w-4 h-4" />
          <span>Verified</span>
        </div>
      </div>

      {/* Image Header */}
      <div className="h-[40vh] w-full relative shrink-0">
        <img src={property.image} alt={property.name} className="w-full h-full object-cover" />
      </div>

      {/* Detail Card Overlay */}
      <div className="flex-1 bg-white flex flex-col rounded-t-[2rem] p-6 relative z-10 -mt-6 shadow-[0_-8px_30px_rgba(0,0,0,0.05)] pt-8 pb-8">
        <div className="flex justify-between items-start mb-2">
          <h1 className="text-[22px] font-bold text-gray-900 mb-2">{property.name}</h1>
        </div>

        <div className="flex justify-between items-center mb-4 text-sm font-semibold text-gray-500">
           <div className="flex items-center gap-1.5">
             <Star className="w-4 h-4 text-orange-400 fill-orange-400" />
             <span className="text-gray-900 font-bold">{property.rating}</span>
             <span>({property.reviews} Reviews)</span>
           </div>
           <div className="flex items-center gap-1.5 opacity-80">
             <MapPin className="w-4 h-4" />
             <span>{property.location}</span>
           </div>
        </div>

        <div className="flex items-end gap-1 mb-6 mt-2">
          <span className="text-2xl font-bold text-gray-900">{formatPrice(property.price)}</span>
          <span className="text-[13px] font-semibold text-gray-500 mb-1">/month</span>
        </div>

        {/* Labels/Categories */}
        <div className="flex flex-wrap gap-2.5 mb-8">
          <div className="px-4 py-2 rounded-[0.8rem] border border-gray-100 bg-gray-50 text-[13px] font-bold text-gray-700 flex items-center gap-1.5">
            <Home className="w-4 h-4 text-gray-400" />
            {property.category}
          </div>
          <div className="px-4 py-2 rounded-[0.8rem] border border-gray-100 bg-gray-50 text-[13px] font-bold text-gray-700 flex items-center gap-1.5">
            <Maximize className="w-4 h-4 text-gray-400" />
            {property.features.rooms} Room
          </div>
          {property.features.furnished && (
            <div className="px-4 py-2 rounded-[0.8rem] border border-gray-100 bg-gray-50 text-[13px] font-bold text-gray-700 flex items-center gap-1.5">
              <Sofa className="w-4 h-4 text-gray-400" />
              Furnished
            </div>
          )}
        </div>

        {/* Amenities Row */}
        <div className="flex items-center gap-6 mb-8 mt-2 justify-between px-2">
            {property.amenities.slice(0, 4).map(key => (
              <div key={key} className="flex flex-col items-center gap-2">
                  <div className="w-12 h-12 rounded-full border border-gray-100 bg-blue-50/50 flex items-center justify-center">
                     {getAmenityIcon(key)}
                  </div>
                  <span className="text-[11px] text-gray-600 font-bold capitalize">{key}</span>
              </div>
            ))}
        </div>

        {/* Navigation Links */}
        <div className="flex flex-col gap-3 mb-6">
           <button onClick={onViewAmenities} className="w-full bg-slate-50 border border-gray-100 p-4 rounded-[1.2rem] flex justify-between items-center hover:bg-slate-100 transition-colors">
              <span className="font-bold text-gray-900 text-[15px]">Amenities</span>
              <ChevronRight className="w-5 h-5 text-gray-400" />
           </button>
           <button onClick={onViewGallery} className="w-full bg-slate-50 border border-gray-100 p-4 rounded-[1.2rem] flex justify-between items-center hover:bg-slate-100 transition-colors">
              <div className="flex items-center gap-3">
                 <span className="font-bold text-gray-900 text-[15px]">Photo Gallery</span>
                 <span className="bg-primary/10 text-primary font-bold text-[11px] px-2 py-0.5 rounded-md">34 Photos</span>
              </div>
              <ChevronRight className="w-5 h-5 text-gray-400" />
           </button>
           <button onClick={onViewLocation} className="w-full bg-slate-50 border border-gray-100 p-4 rounded-[1.2rem] flex justify-between items-center hover:bg-slate-100 transition-colors">
              <span className="font-bold text-gray-900 text-[15px]">Location</span>
              <ChevronRight className="w-5 h-5 text-gray-400" />
           </button>
           <button onClick={onViewLandlord} className="w-full bg-slate-50 border border-gray-100 p-4 rounded-[1.2rem] flex justify-between items-center hover:bg-slate-100 transition-colors">
              <span className="font-bold text-gray-900 text-[15px]">Landlord Info</span>
              <ChevronRight className="w-5 h-5 text-gray-400" />
           </button>
        </div>

        {/* About Property */}
        <h3 className="text-[17px] font-bold text-gray-900 mb-3 mt-4">About Property</h3>
        <p className="text-gray-500 text-[14px] font-medium leading-[1.6] mb-8">
          {property.description}
        </p>

        {/* Bottom Action Bar */}
        <div className="flex items-center gap-4 mt-auto">
          <button 
            onClick={onMessage} 
            className="h-14 flex-1 border-[1.5px] border-primary/20 rounded-[1.2rem] flex items-center justify-center text-primary bg-primary/5 font-bold text-[15px] transition-transform active:scale-[0.98]"
          >
            Message
          </button>
          <button 
            onClick={onBook}
            className="h-14 bg-primary text-white rounded-[1.2rem] flex-[1.5] font-bold text-[15px] shadow-[0_8px_20px_-6px_rgba(78,70,229,0.4)] transition-transform active:scale-[0.98]"
          >
            Book a Visit
          </button>
        </div>
      </div>
    </div>
  );
}
