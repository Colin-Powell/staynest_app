import { MapPin, Search as SearchIcon, SlidersHorizontal, Star, Map, X, Heart, Bell, ChevronLeft, ArrowUpDown } from 'lucide-react';
import { useState, useEffect } from 'react';
import { formatPrice, properties } from '../data';
import FilterView from './FilterView';
import MapView from './MapView';

export default function SearchView({ onSelectProperty, onToggleMap, onBack, onMoreFilters }: { onSelectProperty: (id: string) => void, onToggleMap: (visible: boolean) => void, onBack?: () => void, onMoreFilters?: () => void }) {
  const [showFilter, setShowFilter] = useState(false);
  const [showMap, setShowMap] = useState(false);
  
  useEffect(() => {
    if (onToggleMap) onToggleMap(showMap);
    return () => { if (onToggleMap) onToggleMap(false); };
  }, [showMap, onToggleMap]);

  return (
    <>
      <div className={`flex-1 overflow-y-auto w-full bg-[#f8f9fa] no-scrollbar ${showMap ? 'hidden' : 'pb-24'} animate-in fade-in zoom-in-95 duration-200 relative`}>
        <div className="px-6 pt-12 pb-4 bg-[#f8f9fa] sticky top-0 z-10">
            <div className="flex justify-between items-center mb-6">
              <div className="flex items-center gap-4">
                <button 
                  onClick={onBack}
                  className="w-10 h-10 flex items-center justify-center rounded-full border border-gray-200 bg-white shadow-sm"
                >
                  <ChevronLeft className="w-5 h-5 text-gray-700" />
                </button>
                <h1 className="text-xl font-bold text-gray-900">Search</h1>
              </div>
              <button className="w-10 h-10 rounded-full border border-gray-200 bg-white shadow-sm flex items-center justify-center relative hover:bg-gray-50">
                  <div className="absolute top-2.5 right-3 w-2 h-2 bg-red-500 rounded-full border-[1.5px] border-white"></div>
                  <Bell className="w-5 h-5 text-gray-700" />
              </button>
            </div>
            
            <p className="text-[17px] font-bold text-gray-900 mb-4">Where do you want to live?</p>
            
            <div className="flex-1 bg-white rounded-2xl flex items-center px-4 py-3.5 shadow-sm border border-gray-100 mb-5 focus-within:border-primary/30 focus-within:ring-2 focus-within:ring-primary/10 transition-all">
              <SearchIcon className="text-gray-400 w-5 h-5 mr-3 shrink-0" />
              <input
                type="text"
                placeholder="Where do you want to live?"
                className="bg-transparent border-none outline-none flex-1 font-medium text-gray-900 placeholder-gray-400 w-full"
                defaultValue="New York, USA"
              />
              <button onClick={() => setShowMap(true)} className="ml-2 w-8 h-8 flex -mr-1 items-center justify-center rounded-full bg-gray-50 hover:bg-gray-100">
                <Map className="w-4 h-4 text-gray-500" />
              </button>
            </div>
            
            <div className="flex gap-4">
              <button 
                 onClick={() => setShowFilter(true)}
                 className="bg-white rounded-2xl px-5 py-2.5 flex flex-1 gap-2 items-center justify-center border border-gray-100 shadow-sm font-semibold text-gray-700 hover:bg-gray-50"
              >
                <SlidersHorizontal className="text-gray-700 w-4 h-4" />
                Filters
              </button>
              <button 
                 className="bg-white rounded-2xl px-5 py-2.5 flex flex-1 gap-2 items-center justify-center border border-gray-100 shadow-sm font-semibold text-gray-700 hover:bg-gray-50"
              >
                <ArrowUpDown className="text-gray-700 w-4 h-4" />
                Sort
              </button>
            </div>
        </div>

        <div className="px-6 py-2 pb-28">
          <div className="flex flex-col gap-5">
            {properties.map((property) => (
              <div
                key={`search-${property.id}`}
                className="bg-white rounded-3xl p-3.5 flex gap-4 hover:shadow-[0_8px_30px_rgba(0,0,0,0.06)] transition-shadow cursor-pointer"
                onClick={() => onSelectProperty(property.id)}
              >
                <div className="w-[100px] h-[100px] rounded-2xl overflow-hidden shrink-0 relative">
                  <img src={property.image} alt={property.name} className="w-full h-full object-cover" />
                  <div className="absolute top-2 left-2 bg-white/90 backdrop-blur-sm px-1.5 py-0.5 rounded-md flex items-center gap-0.5">
                    <Star className="w-2.5 h-2.5 text-orange-400 fill-orange-400" />
                    <span className="text-[10px] font-bold text-gray-900">{property.rating}</span>
                  </div>
                </div>
                <div className="flex-1 py-1 flex flex-col pt-0.5">
                  <div className="flex justify-between items-start mb-1">
                    <h3 className="font-bold text-[16px] text-gray-900 leading-tight">{property.name}</h3>
                    <button className="text-gray-300 hover:text-red-500">
                      <Heart className="w-4 h-4 fill-current" />
                    </button>
                  </div>
                  <div className="flex items-center text-gray-500 text-sm mb-2 opacity-80">
                     <MapPin className="w-3.5 h-3.5 mr-1 shrink-0" />
                     <p className="truncate font-medium">{property.location}</p>
                  </div>
                  <div className="flex items-end justify-between mt-auto">
                    <div className="flex items-baseline gap-1 font-bold text-gray-900 text-[17px]">
                      {formatPrice(property.price)}<span className="text-xs font-semibold text-gray-500 font-sans">/month</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-gray-500 text-xs font-semibold">
                      <span>{property.features.beds} Beds</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      {showFilter && <FilterView onClose={() => setShowFilter(false)} onMoreFilters={onMoreFilters} />}
      {showMap && <MapView onSelectProperty={onSelectProperty} onBack={() => setShowMap(false)} onFilter={() => { setShowMap(false); setShowFilter(true); }} />}
    </>
  );
}
