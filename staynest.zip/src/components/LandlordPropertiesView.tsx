import { Plus, MoreVertical } from 'lucide-react';
import { formatPrice, properties } from '../data';

export default function LandlordPropertiesView({ onAddProperty }: { onAddProperty: () => void }) {
  return (
    <div className="flex-1 overflow-y-auto w-full bg-[#f8f9fa] no-scrollbar pb-32 animate-in fade-in zoom-in-95 duration-200">
      <div className="px-6 pt-12 pb-4 bg-[#f8f9fa] sticky top-0 z-10 flex justify-between items-center">
         <h1 className="text-xl font-bold text-gray-900">My Properties</h1>
         <button onClick={onAddProperty} className="w-10 h-10 bg-primary/10 text-primary rounded-full flex items-center justify-center hover:bg-primary/20">
            <Plus className="w-5 h-5" />
         </button>
      </div>

      <div className="px-6 py-6 flex flex-col gap-5 pb-28">
         {properties.map(p => (
           <div key={p.id} className="bg-white rounded-3xl p-3 hover:shadow-[0_8px_30px_rgba(0,0,0,0.06)] transition-shadow flex gap-4">
              <div className="w-[100px] h-[100px] rounded-[1.25rem] overflow-hidden shrink-0">
                 <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
              </div>
              <div className="flex-1 py-1 pr-1 flex flex-col">
                 <div className="flex justify-between items-start mb-1">
                    <h3 className="font-bold text-gray-900 truncate pr-2">{p.name}</h3>
                    <button className="text-gray-400 p-1 -mr-1"><MoreVertical className="w-4 h-4" /></button>
                 </div>
                 <p className="text-xs font-semibold text-gray-500 mb-2 truncate">{p.location}</p>
                 <div className="text-sm font-bold text-primary mb-auto">{formatPrice(p.price)}/m</div>
                 <div className="flex justify-between items-center mt-2">
                    <span className="text-[10px] font-bold text-gray-400">12 Inquiries</span>
                    <span className="bg-green-500/10 text-green-600 text-[10px] font-bold px-2 py-1 rounded-lg">Published</span>
                 </div>
              </div>
           </div>
         ))}
      </div>
    </div>
  );
}
