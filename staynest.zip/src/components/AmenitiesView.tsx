import { ChevronLeft, CheckCircle2, Zap, Droplets, CircleParking, ShieldCheck } from 'lucide-react';

export default function AmenitiesView({ onClose }: { onClose: () => void }) {
  const groups = [
    { title: 'Essential', items: [
       { icon: <Zap className="w-6 h-6 text-primary" />, label: 'Electricity\nIncluded' },
       { icon: <Droplets className="w-6 h-6 text-primary" />, label: 'Water\nIncluded' },
       { icon: <CircleParking className="w-6 h-6 text-primary" />, label: 'Parking\nAvailable' },
    ]},
    { title: 'Additional', items: [
       { label: 'Balcony' },
       { label: 'Shared Kitchen' },
       { label: 'Ensuite Bathroom' },
       { label: 'Borehole Water' },
       { label: 'Laundry Area' },
       { label: 'Gym Access' },
       { label: 'CCTV' },
       { label: 'Security Guards' }
    ]}
  ];

  return (
    <div className="flex-1 w-full bg-[#f8f9fa] flex flex-col h-full animate-in fade-in slide-in-from-right-4 duration-300 z-50 absolute inset-0">
      <div className="px-6 pt-12 pb-4 flex items-center sticky top-0 bg-[#f8f9fa] z-10 gap-3">
        <button onClick={onClose} className="text-gray-900 active:scale-95 transition-transform">
           <ChevronLeft className="w-6 h-6" />
        </button>
        <h2 className="text-xl font-bold text-gray-900">Amenities</h2>
      </div>
      
      <div className="flex-1 overflow-y-auto px-6 py-4 pb-28 no-scrollbar">
         {groups.map(g => (
            <div key={g.title} className="mb-8">
               <h3 className="text-[17px] font-bold text-gray-900 mb-6">{g.title}</h3>
               {g.title === 'Essential' ? (
                  <div className="flex gap-4">
                     {g.items.map((item, i) => (
                        <div key={i} className="flex-1 bg-white border border-gray-100 rounded-2xl p-4 flex flex-col items-center justify-center text-center gap-2 shadow-sm">
                           {item.icon}
                           <span className="text-[11px] font-bold text-gray-600 whitespace-pre-line leading-tight">{item.label}</span>
                        </div>
                     ))}
                  </div>
               ) : (
                  <div className="flex flex-col gap-4">
                     {g.items.map((item, i) => (
                        <div key={i} className="flex items-center gap-3">
                           <div className="w-6 h-6 rounded-full bg-green-50 text-green-500 flex items-center justify-center border border-green-100">
                              <CheckCircle2 className="w-4 h-4" />
                           </div>
                           <span className="font-semibold text-[15px] text-gray-700">{item.label}</span>
                        </div>
                     ))}
                  </div>
               )}
            </div>
         ))}
      </div>
    </div>
  );
}
