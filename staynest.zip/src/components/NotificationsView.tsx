import { ChevronLeft, CheckCircle2, MessageSquare, DollarSign, Star, Info } from 'lucide-react';

const NOTIFICATIONS = [
  { id: 1, type: 'success', title: 'Booking Confirmed', msg: 'Your booking for 11 Green Bank is confirmed.', time: '2m' },
  { id: 2, type: 'message', title: 'New Message', msg: 'John Kamau sent you a message.', time: '10m' },
  { id: 3, type: 'price', title: 'Price Drop', msg: 'Sunset Apartment price dropped by $100.', time: '1h' },
  { id: 4, type: 'info', title: 'New Property', msg: '5 new properties available near you.', time: '3h' },
  { id: 5, type: 'success', title: 'Verification Update', msg: 'Your profile has been verified.', time: '1d' }
];

export default function NotificationsView({ onBack }: { onBack: () => void }) {
  
  const getIcon = (type: string) => {
    switch (type) {
      case 'success': return <div className="w-10 h-10 rounded-full bg-green-500/10 text-green-500 flex items-center justify-center shrink-0"><CheckCircle2 className="w-5 h-5" /></div>;
      case 'message': return <div className="w-10 h-10 rounded-full bg-blue-500/10 text-blue-500 flex items-center justify-center shrink-0"><MessageSquare className="w-4 h-4" /></div>;
      case 'price': return <div className="w-10 h-10 rounded-full bg-red-500/10 text-red-500 flex items-center justify-center shrink-0"><DollarSign className="w-5 h-5" /></div>;
      default: return <div className="w-10 h-10 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0"><Info className="w-5 h-5" /></div>;
    }
  };

  return (
    <div className="flex-1 w-full bg-white flex flex-col h-full animate-in fade-in slide-in-from-right-4 duration-300 z-50 absolute inset-0">
      <div className="px-6 pt-12 pb-4 flex items-center sticky top-0 bg-white/80 backdrop-blur-md border-b border-gray-50 z-10">
        <button onClick={onBack} className="w-10 h-10 rounded-full border border-gray-100 flex items-center justify-center hover:bg-gray-50 shrink-0">
           <ChevronLeft className="w-6 h-6 text-gray-900" />
        </button>
        <h2 className="text-lg font-bold text-gray-900 flex-1 text-center pr-10">Notifications</h2>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-4 flex flex-col gap-6">
        {NOTIFICATIONS.map((notif, idx) => (
          <div key={notif.id}>
             <div className="flex gap-4">
                {getIcon(notif.type)}
                <div className="flex-1 min-w-0">
                   <div className="flex justify-between items-center mb-1">
                      <h4 className="font-bold text-[15px] text-gray-900">{notif.title}</h4>
                      <span className="text-xs font-semibold text-gray-400">{notif.time}</span>
                   </div>
                   <p className="text-sm font-medium text-gray-500">{notif.msg}</p>
                </div>
             </div>
             {idx < NOTIFICATIONS.length - 1 && <div className="ml-14 h-[1px] bg-gray-50 mt-6 box-border"></div>}
          </div>
        ))}
      </div>
    </div>
  );
}
