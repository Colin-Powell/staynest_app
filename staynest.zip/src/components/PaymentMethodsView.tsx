import { ChevronLeft, Plus } from 'lucide-react';

export default function PaymentMethodsView({ onBack }: { onBack: () => void }) {
  return (
    <div className="flex-1 w-full bg-slate-50 flex flex-col h-full animate-in fade-in slide-in-from-right-4 duration-300 z-50 absolute inset-0">
      <div className="px-6 py-6 pt-12 flex items-center sticky top-0 bg-white/80 backdrop-blur-md border-b border-gray-50 z-10 text-center">
         <button onClick={onBack} className="w-10 h-10 rounded-full border border-gray-100 flex items-center justify-center hover:bg-gray-50 flex-shrink-0 absolute left-6">
            <ChevronLeft className="w-6 h-6 text-gray-900" />
         </button>
         <h2 className="text-lg font-bold text-gray-900 flex-1">Payment Methods</h2>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-6 flex flex-col gap-4">
         {/* M-Pesa */}
         <div className="bg-white rounded-[1.5rem] p-5 shadow-sm border border-gray-100 flex items-center justify-between">
            <div className="flex gap-4 items-center">
               <div className="w-12 h-12 rounded-xl bg-green-50 flex items-center justify-center text-green-600 font-bold text-xs ring-1 ring-green-100">
                  M-Pesa
               </div>
               <div>
                  <h3 className="font-bold text-gray-900 mb-1">M-Pesa</h3>
                  <p className="text-sm font-semibold text-gray-500">0712 345 678</p>
               </div>
            </div>
            <div className="bg-primary/10 text-primary text-[10px] font-bold px-3 py-1.5 rounded-lg border border-primary/20">
               Default
            </div>
         </div>

         {/* Visa */}
         <div className="bg-white rounded-[1.5rem] p-5 shadow-sm border border-gray-100 flex items-center justify-between">
            <div className="flex gap-4 items-center">
               <div className="w-12 h-12 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600 font-bold text-lg ring-1 ring-blue-100 italic">
                  VISA
               </div>
               <div>
                  <h3 className="font-bold text-gray-900 mb-1">Visa &bull;&bull;&bull;&bull; 4242</h3>
                  <p className="text-sm font-semibold text-gray-500">Expires 12/26</p>
               </div>
            </div>
         </div>
      </div>

      <div className="p-6 bg-white border-t border-gray-100">
         <button 
           className="w-full h-14 bg-primary text-white rounded-2xl font-bold text-[15px] shadow-lg shadow-primary/30 active:scale-[0.98] transition-transform flex items-center justify-center gap-2"
         >
           <Plus className="w-5 h-5" /> Add Payment Method
         </button>
      </div>
    </div>
  );
}
