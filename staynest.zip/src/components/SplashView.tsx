import { useState } from 'react';

export default function SplashView({ onNext }: { onNext: () => void }) {
  return (
    <div className="flex-1 w-full bg-primary flex flex-col items-center justify-center p-6 h-full relative overflow-hidden animate-in fade-in duration-300 z-50">
      
      {/* Background decoration */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] bg-white/5 rounded-full blur-[80px]"></div>
      
      <div className="flex flex-col items-center justify-center flex-1 max-w-[280px] w-full text-center relative z-10">
        <div className="w-20 h-20 bg-white shadow-xl shadow-black/10 rounded-[1.5rem] flex items-center justify-center mb-8 rotate-3">
          <svg className="w-10 h-10 text-primary -rotate-3" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 2L2 12h3v8h6v-6h2v6h6v-8h3L12 2z" />
          </svg>
        </div>
        
        <h1 className="text-4xl font-bold text-white mb-2 tracking-tight">StayNest</h1>
        <p className="text-primary-foreground/90 font-medium text-lg mb-4">Find. Rent. Live.</p>
        
        <p className="text-primary-foreground/70 text-sm mb-12">
          Your perfect place is<br/>just a tap away.
        </p>
      </div>

      <div className="w-full mt-auto mb-6 shrink-0 relative z-10 flex flex-col gap-4">
        <button 
          onClick={onNext}
          className="w-full h-14 bg-white text-primary rounded-[1.2rem] font-bold text-[15px] shadow-[0_8px_30px_rgba(0,0,0,0.12)] active:scale-[0.98] transition-transform"
        >
          Get Started
        </button>
        <button 
          onClick={onNext}
          className="w-full h-14 bg-transparent border border-white/20 text-white rounded-[1.2rem] font-bold text-[15px] hover:bg-white/5 active:scale-[0.98] transition-all"
        >
          Login
        </button>
      </div>
      
      <button onClick={onNext} className="text-white/60 text-sm font-semibold mb-2 hover:text-white pb-6 z-10">
        Explore as Guest
      </button>
    </div>
  );
}
