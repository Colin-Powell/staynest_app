import { ChevronLeft } from 'lucide-react';
import { useState } from 'react';

export default function EditProfileView({ onBack, onSave }: { onBack: () => void, onSave: () => void }) {
  const [name, setName] = useState('Jomision Munene');
  const [phone, setPhone] = useState('+254 712 345 678');
  const [email, setEmail] = useState('jomision@example.com');

  return (
    <div className="flex-1 w-full bg-white flex flex-col h-full animate-in fade-in slide-in-from-right-4 duration-300 z-50 absolute inset-0">
      <div className="px-6 py-6 pt-12 flex items-center sticky top-0 bg-white/80 backdrop-blur-md border-b border-gray-50 z-10 text-center">
         <button onClick={onBack} className="w-10 h-10 rounded-full border border-gray-100 flex items-center justify-center hover:bg-gray-50 flex-shrink-0 absolute left-6">
            <ChevronLeft className="w-6 h-6 text-gray-900" />
         </button>
         <h2 className="text-lg font-bold text-gray-900 flex-1">Edit Profile</h2>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-8 flex flex-col">
         {/* Avatar */}
         <div className="flex flex-col items-center mb-8">
            <div className="relative">
               <img src="https://i.pravatar.cc/150?img=12" alt="Avatar" className="w-[100px] h-[100px] rounded-full object-cover shadow-md border-4 border-white" />
            </div>
            <button className="text-sm font-bold text-primary mt-3 hover:text-primary/80 transition-colors">Change Photo</button>
         </div>

         {/* Form Fields */}
         <div className="flex flex-col gap-5">
            <div className="space-y-2">
               <label className="text-sm font-bold text-gray-700">Full Name</label>
               <input 
                 type="text" 
                 value={name} 
                 onChange={(e) => setName(e.target.value)}
                 className="w-full bg-gray-50 border border-gray-200 rounded-2xl px-5 py-3.5 text-[15px] font-semibold text-gray-900 focus:border-primary/50 focus:ring-2 focus:ring-primary/10 outline-none transition-all" 
               />
            </div>
            <div className="space-y-2">
               <label className="text-sm font-bold text-gray-700">Phone Number</label>
               <input 
                 type="tel" 
                 value={phone} 
                 onChange={(e) => setPhone(e.target.value)}
                 className="w-full bg-gray-50 border border-gray-200 rounded-2xl px-5 py-3.5 text-[15px] font-semibold text-gray-900 focus:border-primary/50 focus:ring-2 focus:ring-primary/10 outline-none transition-all" 
               />
            </div>
            <div className="space-y-2">
               <label className="text-sm font-bold text-gray-700">Email Address</label>
               <input 
                 type="email" 
                 value={email} 
                 onChange={(e) => setEmail(e.target.value)}
                 className="w-full bg-gray-50 border border-gray-200 rounded-2xl px-5 py-3.5 text-[15px] font-semibold text-gray-900 focus:border-primary/50 focus:ring-2 focus:ring-primary/10 outline-none transition-all" 
               />
            </div>
         </div>
      </div>

      <div className="p-6 bg-white border-t border-gray-100">
         <button 
           onClick={onSave}
           className="w-full h-14 bg-primary text-white rounded-2xl font-bold text-[15px] shadow-lg shadow-primary/30 active:scale-[0.98] transition-transform"
         >
           Save Changes
         </button>
      </div>
    </div>
  );
}
