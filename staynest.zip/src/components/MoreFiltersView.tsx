import { ChevronLeft } from 'lucide-react';
import { useState } from 'react';

export default function MoreFiltersView({ onClose }: { onClose: () => void }) {
  const [occupancy, setOccupancy] = useState('Any');
  const [furnishing, setFurnishing] = useState('Any');
  const [availability, setAvailability] = useState('Anytime');
  const [sort, setSort] = useState('Newest First');
  const [distance, setDistance] = useState(5);

  return (
    <div className="flex-1 overflow-y-auto w-full bg-[#f8f9fa] no-scrollbar pb-32 animate-in fade-in slide-in-from-right-4 duration-300 relative z-[60]">
      <div className="px-6 pt-12 pb-4 bg-[#f8f9fa] sticky top-0 z-10 flex items-center">
        <button 
          onClick={onClose}
          className="w-10 h-10 flex items-center justify-center rounded-full border border-gray-200 bg-white shadow-sm shrink-0"
        >
          <ChevronLeft className="w-5 h-5 text-gray-700" />
        </button>
        <h2 className="text-[17px] font-bold text-gray-900 flex-1 text-center pr-10">More Filters</h2>
      </div>

      <div className="px-6 py-4 flex flex-col gap-8 pb-32">
        {/* Occupancy */}
        <div>
           <h3 className="text-[15px] font-bold text-gray-900 mb-3">Occupancy</h3>
           <div className="flex gap-2">
             {['Any', 'Male Only', 'Female Only'].map(opt => (
               <button 
                 key={opt}
                 onClick={() => setOccupancy(opt)}
                 className={`flex-1 py-3 text-[13px] font-bold rounded-[1rem] border transition-colors ${occupancy === opt ? 'border-primary bg-primary/5 text-primary' : 'border-gray-200 bg-white text-gray-500'}`}
               >
                 {opt}
               </button>
             ))}
           </div>
        </div>

        {/* Furnishing */}
        <div>
           <h3 className="text-[15px] font-bold text-gray-900 mb-3">Furnishing</h3>
           <div className="flex gap-2">
             {['Any', 'Furnished', 'Unfurnished'].map(opt => (
               <button 
                 key={opt}
                 onClick={() => setFurnishing(opt)}
                 className={`flex-1 py-3 text-[13px] font-bold rounded-[1rem] border transition-colors ${furnishing === opt ? 'border-primary bg-primary/5 text-primary' : 'border-gray-200 bg-white text-gray-500'}`}
               >
                 {opt}
               </button>
             ))}
           </div>
        </div>

        {/* Availability */}
        <div>
           <h3 className="text-[15px] font-bold text-gray-900 mb-3">Availability</h3>
           <div className="flex gap-2">
             {['Anytime', 'Available Now', 'Future'].map(opt => (
               <button 
                 key={opt}
                 onClick={() => setAvailability(opt)}
                 className={`flex-1 py-3 text-[13px] font-bold rounded-[1rem] border transition-colors ${availability === opt ? 'border-primary bg-primary/5 text-primary' : 'border-gray-200 bg-white text-gray-500'}`}
               >
                 {opt}
               </button>
             ))}
           </div>
        </div>

        {/* Distance Radius */}
        <div>
           <h3 className="text-[15px] font-bold text-gray-900 mb-3">Distance Radius</h3>
           <div className="px-2 mb-2 relative">
             <div className="h-1 bg-gray-200 rounded-full relative mb-6">
                <div 
                   className="absolute bg-primary h-full rounded-full left-0" 
                   style={{ width: `${(distance/30)*100}%` }}
                ></div>
             </div>
             
             <input 
               type="range" 
               min="1" max="30" step="1"
               value={distance}
               onChange={(e) => setDistance(parseInt(e.target.value))}
               className="absolute top-0 left-2 right-2 w-[calc(100%-16px)] h-1 opacity-0 outline-none pointer-events-auto z-20 cursor-pointer" 
             />
             <div 
                className="w-5 h-5 bg-white border-[4px] border-primary rounded-full absolute top-[-8px] -translate-x-1/2 shadow-sm pointer-events-none z-10"
                style={{ left: `calc(0.5rem + ${(distance/30) * 100}%)` }}
             ></div>

             <div className="flex justify-between items-center text-[13px] font-bold text-gray-500 mt-4">
               <span>1 km</span>
               <span>30+ km</span>
             </div>
           </div>
        </div>

        {/* Sort By */}
        <div>
           <h3 className="text-[15px] font-bold text-gray-900 mb-3">Sort By</h3>
           <select 
             value={sort} onChange={(e) => setSort(e.target.value)}
             className="w-full bg-white border border-gray-200 rounded-[1rem] py-3.5 px-4 outline-none font-bold text-gray-900 text-[14px] appearance-none"
           >
             <option>Newest First</option>
             <option>Price: Low to High</option>
             <option>Price: High to Low</option>
             <option>Rating: High to Low</option>
           </select>
        </div>
      </div>

      <div className="fixed bottom-0 left-0 right-0 p-6 bg-white pb-8 z-30 shadow-[0_-10px_20px_rgba(0,0,0,0.02)] sm:rounded-b-[2.5rem]">
         <div className="flex gap-4">
           <button 
             onClick={() => { setOccupancy('Any'); setFurnishing('Any'); setAvailability('Anytime'); setDistance(5); }}
             className="w-1/3 h-14 bg-gray-100 text-gray-900 rounded-[1.2rem] font-bold text-[15px] active:scale-[0.98] transition-transform"
           >
             Reset
           </button>
           <button 
             onClick={onClose}
             className="flex-1 h-14 bg-primary text-white rounded-[1.2rem] font-bold text-[15px] shadow-[0_8px_20px_-6px_rgba(78,70,229,0.4)] active:scale-[0.98] transition-transform"
           >
             Apply
           </button>
         </div>
      </div>
    </div>
  );
}
