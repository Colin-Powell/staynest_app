import { ChevronLeft, Star, ShieldCheck, FileCheck, CheckCircle2 } from 'lucide-react';

export default function LandlordInfoView({ onClose }: { onClose: () => void }) {
  return (
    <div className="flex-1 w-full bg-[#f8f9fa] flex flex-col h-full animate-in fade-in slide-in-from-right-4 duration-300 z-50 absolute inset-0">
      <div className="px-6 pt-12 pb-4 flex items-center sticky top-0 bg-[#f8f9fa] z-10 gap-3">
        <button onClick={onClose} className="text-gray-900 active:scale-95 transition-transform">
           <ChevronLeft className="w-6 h-6" />
        </button>
        <h2 className="text-xl font-bold text-gray-900">Landlord Info</h2>
      </div>
      
      <div className="flex-1 overflow-y-auto px-6 py-4 pb-32">
         {/* Side-by-side info, no card */}
         <div className="flex bg-[#f8f9fa] items-start gap-4 mb-6">
            <div className="w-16 h-16 shrink-0 bg-white rounded-full flex items-center justify-center text-green-500 border border-green-100 shadow-sm relative">
               <ShieldCheck className="w-8 h-8" />
            </div>
            <div className="flex-1 flex flex-col items-start pt-1">
               <h3 className="text-[19px] font-bold text-gray-900">GreenHomes Ltd.</h3>
               <p className="text-xs font-bold text-green-600 bg-green-100 px-2 py-0.5 rounded flex items-center gap-1 mt-1 mb-2">
                 <CheckCircle2 className="w-3 h-3" /> Verified Landlord
               </p>
               <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 text-orange-400 fill-orange-400" />
                  <span className="font-bold text-gray-900 text-sm">4.8</span>
                  <span className="font-semibold text-gray-500 text-[13px] hover:underline cursor-pointer">(125 reviews)</span>
               </div>
            </div>
         </div>

         <div className="grid grid-cols-3 w-full gap-4 mt-6 pt-6 border-t border-gray-200 mb-8">
            <div>
              <p className="font-bold text-gray-900 text-lg">96%</p>
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Response Rate</p>
            </div>
            <div>
              <p className="font-bold text-gray-900 text-lg">32</p>
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Properties</p>
            </div>
            <div>
              <p className="font-bold text-gray-900 text-[15px] mt-0.5">May 2022</p>
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mt-0.5">Member Since</p>
            </div>
         </div>

         <h3 className="text-[17px] font-bold text-gray-900 mb-3">About</h3>
         <p className="text-[14px] font-medium text-gray-500 leading-[1.6] mb-8">
           We are a trusted property management company specializing in quality rentals across Nairobi.
         </p>

         <h3 className="text-[17px] font-bold text-gray-900 mb-4">Documents Verified</h3>
         <div className="flex flex-col gap-3">
            {[
              'ID / Passport', 
              'Business Registration',
              'Property Ownership',
              'KRA PIN Certificate'
            ].map(doc => (
               <div key={doc} className="flex items-center gap-3 bg-white border border-gray-100 p-4 rounded-xl shadow-sm">
                  <div className="w-8 h-8 rounded-full bg-green-50 flex items-center justify-center text-green-500">
                    <FileCheck className="w-4 h-4" />
                  </div>
                  <span className="font-bold text-[14px] text-gray-700 flex-1">{doc}</span>
                  <CheckCircle2 className="w-5 h-5 text-green-400" />
               </div>
            ))}
         </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 p-6 bg-white z-30 shadow-[0_-10px_20px_rgba(0,0,0,0.02)] pb-8 border-t border-gray-100">
         <button className="w-full h-14 bg-primary text-white rounded-[1.2rem] font-bold text-[15px] shadow-[0_8px_20px_-6px_rgba(78,70,229,0.4)] active:scale-[0.98] transition-transform">
           View All Properties (32)
         </button>
      </div>
    </div>
  );
}
