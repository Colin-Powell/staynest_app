import { ArrowRight, MapPin, Search, SlidersHorizontal, Star, Bell } from 'lucide-react';
import { formatPrice, properties } from '../data';

const FILTERS = ['Apartment', 'Bedsitter', 'Single Room', '1 Bedroom'];

export default function HomeView({ onSelectProperty, onNotifications }: { onSelectProperty: (id: string) => void, onNotifications: () => void }) {
  return (
    <div className="flex-1 overflow-y-auto w-full bg-[#f8f9fa] no-scrollbar pb-28">
      {/* Header */}
      <div className="px-6 pt-12 pb-4">
        <div className="flex justify-between items-start mb-6">
          <div>
            <p className="text-sm font-semibold text-gray-900 mb-1">Hello, Jomision 👋</p>
            <h1 className="text-3xl font-bold text-gray-900 leading-tight">
              Find your<br />perfect place
            </h1>
          </div>
          <div className="flex items-center gap-3">
             <button onClick={onNotifications} className="w-10 h-10 rounded-full border border-gray-200 bg-white shadow-sm flex items-center justify-center relative hover:bg-gray-50">
                <div className="absolute top-2.5 right-3 w-2 h-2 bg-red-500 rounded-full border-[1.5px] border-white"></div>
                <Bell className="w-5 h-5 text-gray-700" />
             </button>
             <img 
               src="https://i.pravatar.cc/150?img=12" 
               alt="Profile" 
               className="w-10 h-10 rounded-full border-2 border-white shadow-sm object-cover"
             />
          </div>
        </div>

        {/* Search */}
        <div className="flex gap-3 mb-6">
          <div className="flex-1 bg-white rounded-2xl flex items-center px-4 py-3.5 shadow-sm border border-gray-100">
            <Search className="text-gray-400 w-5 h-5 mr-3" />
            <input 
              type="text" 
              placeholder="Search location, area..." 
              className="bg-transparent border-none outline-none flex-1 text-[15px] font-medium text-gray-900 placeholder-gray-400 w-full"
            />
          </div>
        </div>

        {/* Filters */}
        <div className="flex gap-3 overflow-x-auto no-scrollbar -mx-6 px-6 pb-2">
          {FILTERS.map((filter, i) => (
            <button 
              key={filter}
              className={`px-5 py-2.5 rounded-full text-sm font-semibold whitespace-nowrap transition-colors shadow-sm ${
                i === 0 
                  ? 'bg-gray-900 text-white' 
                  : 'bg-white text-gray-600 border border-gray-200'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>
      </div>

      {/* Nearby You Section */}
      <div className="mt-2">
        <div className="flex justify-between items-center px-6 mb-4">
          <h2 className="text-[17px] font-bold text-gray-900">Nearby You</h2>
          <button className="text-sm font-semibold text-gray-400">See all</button>
        </div>
        
        <div className="flex gap-4 overflow-x-auto no-scrollbar -mx-6 px-6 pb-4">
          {properties.slice(0, 2).map((property) => (
            <div 
              key={property.id} 
              className="bg-white rounded-3xl p-3 w-[260px] shrink-0 hover:shadow-[0_8px_30px_rgba(0,0,0,0.06)] transition-shadow cursor-pointer"
              onClick={() => onSelectProperty(property.id)}
            >
              <div className="relative w-full h-[180px] rounded-[1.2rem] overflow-hidden mb-3">
                <img src={property.image} alt={property.name} className="w-full h-full object-cover" />
                <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-lg flex items-center gap-1">
                  <Star className="w-3 h-3 text-orange-400 fill-orange-400" />
                  <span className="text-[11px] font-bold text-gray-900">{property.rating}</span>
                </div>
              </div>
              <div className="px-2 pb-1">
                <div className="flex justify-between items-start mb-1">
                  <h3 className="font-bold text-[17px] text-gray-900 truncate pr-2">{property.name}</h3>
                </div>
                <div className="flex items-center text-gray-500 mb-3 text-sm opacity-80">
                  <MapPin className="w-3.5 h-3.5 mr-1.5 shrink-0" />
                  <p className="truncate font-medium">{property.location}</p>
                </div>
                <div className="flex items-center gap-1 font-bold text-primary text-[17px]">
                  {formatPrice(property.price)}<span className="text-xs font-semibold text-gray-500 font-sans">/month</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recommended For You */}
      <div className="mt-6 px-6">
        <div className="flex justify-between items-center mb-5">
          <h2 className="text-[17px] font-bold text-gray-900">Recommended For You</h2>
          <button className="text-sm font-semibold text-gray-400">See all</button>
        </div>
        
        <div className="flex flex-col gap-4">
          {properties.map((property) => (
            <div 
              key={`rec-${property.id}`} 
              className="bg-white rounded-3xl p-3 flex gap-4 hover:shadow-[0_8px_30px_rgba(0,0,0,0.06)] transition-shadow cursor-pointer items-center"
              onClick={() => onSelectProperty(property.id)}
            >
              <div className="w-[85px] h-[85px] rounded-[1rem] overflow-hidden shrink-0">
                <img src={property.image} alt={property.name} className="w-full h-full object-cover" />
              </div>
              <div className="flex-1 min-w-0 py-1 flex flex-col justify-center">
                <h3 className="font-bold text-[16px] text-gray-900 truncate mb-1">{property.name}</h3>
                <div className="flex items-center text-gray-500 text-sm mb-2 opacity-80">
                   <MapPin className="w-3 h-3 mr-1 shrink-0" />
                   <p className="truncate font-medium">{property.location}</p>
                </div>
                <div className="flex items-end justify-between mt-auto">
                    <div className="flex items-baseline gap-1 font-bold text-gray-900">
                      {formatPrice(property.price)}<span className="text-xs font-semibold text-gray-500 font-sans">/month</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-gray-500 text-xs font-bold">
                       <Star className="w-3 h-3 text-orange-400 fill-orange-400" />
                       <span className="text-gray-900">{property.rating}</span> <span className="font-medium">({property.reviews})</span>
                    </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
