import { ChevronLeft, Building2, Home, BedSingle, DoorOpen } from 'lucide-react';
import { useState } from 'react';

export default function FilterView({ onClose, onMoreFilters }: { onClose: () => void, onMoreFilters?: () => void }) {
  const [selectedType, setSelectedType] = useState('Apartment');
  const [minPrice, setMinPrice] = useState(200);
  const [maxPrice, setMaxPrice] = useState(1500);
  const [selectedAmenities, setSelectedAmenities] = useState<string[]>(['WiFi', 'Water included']);

  const toggleAmenity = (amenity: string) => {
    setSelectedAmenities(prev => 
      prev.includes(amenity) ? prev.filter(a => a !== amenity) : [...prev, amenity]
    );
  };

  const propertyTypes = [
    { name: 'Apartment', icon: <Building2 className="w-6 h-6" /> },
    { name: 'Bedsitter', icon: <Home className="w-6 h-6" /> },
    { name: 'Single Room', icon: <DoorOpen className="w-6 h-6" /> },
    { name: '1 Bedroom', icon: <BedSingle className="w-6 h-6" /> }
  ];

  return (
    <div className="absolute inset-0 z-50 bg-[#f8f9fa] flex flex-col animate-in slide-in-from-bottom-full duration-300 rounded-[inherit]">
      <div className="px-6 py-6 flex justify-between items-center sticky top-0 bg-[#f8f9fa] z-10 pt-12">
        <button 
          onClick={onClose}
          className="w-10 h-10 flex items-center justify-center rounded-full border border-gray-200 bg-white shadow-sm"
        >
          <ChevronLeft className="w-5 h-5 text-gray-700" />
        </button>
        <h2 className="text-[17px] font-bold text-gray-900">Filters</h2>
        <button 
          onClick={() => { setSelectedType(''); setMinPrice(200); setMaxPrice(2000); setSelectedAmenities([]); }} 
          className="text-primary font-bold hover:text-primary/80 text-[15px]"
        >
           Reset
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-2 pb-24">
        {/* Property Type */}
        <h3 className="text-[17px] font-bold text-gray-900 mb-4">Property Type</h3>
        <div className="flex gap-3 overflow-x-auto no-scrollbar -mx-6 px-6 mb-8 pb-2">
           {propertyTypes.map((type) => (
             <button 
               key={type.name}
               onClick={() => setSelectedType(type.name)}
               className={`flex-shrink-0 px-5 pt-4 pb-3 rounded-[1.2rem] flex flex-col items-center justify-center min-w-[95px] gap-2 border transition-colors
                 ${selectedType === type.name ? 'border-primary bg-primary/5 text-primary' : 'border-gray-200 bg-white text-gray-500 hover:bg-gray-50 shadow-sm'}`}
             >
               {type.icon}
               <span className="text-xs font-bold whitespace-nowrap">{type.name}</span>
             </button>
           ))}
        </div>

        {/* Price Range */}
        <h3 className="text-[17px] font-bold text-gray-900 mb-4">Price Range</h3>
        <div className="px-2 mb-8 relative">
           <div className="h-1 bg-gray-200 rounded-full relative mb-6">
              <div 
                 className="absolute bg-primary h-full rounded-full" 
                 style={{ left: `${(minPrice/2000)*100}%`, right: `${100 - (maxPrice/2000)*100}%` }}
              ></div>
           </div>
           
           {/* Invisible Dual inputs for styling */}
           <input 
             type="range" 
             min="0" max="2000" step="50"
             value={minPrice}
             onChange={(e) => setMinPrice(Math.min(parseInt(e.target.value), maxPrice - 50))}
             className="absolute top-0 left-2 right-2 w-[calc(100%-16px)] h-1 opacity-0 outline-none pointer-events-auto z-20 cursor-pointer" 
             style={{ WebkitAppearance: 'none' }}
           />
           <div 
              className="w-5 h-5 bg-white border-[4px] border-primary rounded-full absolute top-[-8px] -translate-x-1/2 shadow-sm pointer-events-none z-10"
              style={{ left: `calc(0.5rem + ${(minPrice/2000) * 100}%)` }}
           ></div>

           <input 
             type="range" 
             min="0" max="2000" step="50"
             value={maxPrice}
             onChange={(e) => setMaxPrice(Math.max(parseInt(e.target.value), minPrice + 50))}
             className="absolute top-0 left-2 right-2 w-[calc(100%-16px)] h-1 opacity-0 outline-none pointer-events-auto z-20 cursor-pointer" 
             style={{ WebkitAppearance: 'none' }}
           />
           <div 
              className="w-5 h-5 bg-white border-[4px] border-primary rounded-full absolute top-[-8px] -translate-x-1/2 shadow-sm pointer-events-none z-10"
              style={{ left: `calc(0.5rem + ${(maxPrice/2000) * 100}%)` }}
           ></div>

           <div className="flex justify-between items-center text-[15px] font-bold text-gray-900 mt-4">
             <span>${minPrice}</span>
             <span>${maxPrice}{maxPrice >= 2000 ? '+' : ''}</span>
           </div>
        </div>

        {/* Amenities */}
        <div className="flex justify-between items-center mb-4 mt-8">
           <h3 className="text-[17px] font-bold text-gray-900">Amenities</h3>
           <button onClick={onMoreFilters} className="text-[13px] font-bold text-primary hover:text-primary/80">More Filters</button>
        </div>
        <div className="flex flex-col gap-5">
           {['WiFi', 'Warm included', 'Electricity included', 'Furnished', 'Parking', 'Security', 'CCTV'].map((amenity) => {
             const isSelected = selectedAmenities.includes(amenity);
             return (
               <label key={amenity} className="flex items-center justify-between cursor-pointer group" onClick={(e) => { e.preventDefault(); toggleAmenity(amenity); }}>
                  <span className="text-[15px] font-bold text-gray-600">{amenity}</span>
                  <div className={`w-5 h-5 rounded-[6px] border-[1.5px] flex items-center justify-center transition-colors
                    ${isSelected ? 'bg-primary border-primary' : 'bg-white border-gray-300 group-hover:border-primary/50'}`}
                  >
                    {isSelected && <svg className="w-3.5 h-3.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>}
                  </div>
               </label>
             );
           })}
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 p-6 bg-white pb-8 rounded-[inherit] z-30 shadow-[0_-10px_20px_rgba(0,0,0,0.02)]">
         <button 
           onClick={onClose}
           className="w-full h-14 bg-primary text-white rounded-[1.2rem] font-bold text-[15px] shadow-[0_8px_20px_-6px_rgba(78,70,229,0.4)] active:scale-[0.98] transition-transform"
         >
           Apply Filters
         </button>
      </div>
    </div>
  );
}
