import { ChevronLeft } from 'lucide-react';

export default function SettingView({ title, onBack }: { title: string, onBack: () => void }) {
  return (
    <div className="flex-1 w-full bg-slate-50 flex flex-col h-full animate-in fade-in slide-in-from-right-4 duration-300 z-50 absolute inset-0">
      <div className="px-6 py-6 pt-12 flex items-center sticky top-0 bg-white/80 backdrop-blur-md border-b border-gray-50 z-10 text-center">
         <button onClick={onBack} className="w-10 h-10 rounded-full border border-gray-100 flex items-center justify-center hover:bg-gray-50 flex-shrink-0 absolute left-6">
            <ChevronLeft className="w-6 h-6 text-gray-900" />
         </button>
         <h2 className="text-lg font-bold text-gray-900 flex-1">{title}</h2>
      </div>
      <div className="flex-1 p-6 flex flex-col items-center justify-center text-center">
         <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center text-gray-300 mb-4">
             <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" /><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
         </div>
         <h3 className="text-gray-900 font-bold mb-2">Under Construction</h3>
         <p className="text-gray-500 font-medium text-sm">The {title} screen is not fully implemented in this MVP demo.</p>
      </div>
    </div>
  );
}
