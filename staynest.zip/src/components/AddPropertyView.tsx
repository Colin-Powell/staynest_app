import { ChevronLeft } from 'lucide-react';
import { useState } from 'react';

export default function AddPropertyView({ onBack, onPublish }: { onBack: () => void, onPublish: () => void }) {
  const [step, setStep] = useState(1);

  return (
    <div className="flex-1 w-full bg-white flex flex-col h-full animate-in fade-in slide-in-from-right-4 duration-300 z-50 absolute inset-0">
      <div className="px-6 py-6 pt-12 flex items-center sticky top-0 bg-white/80 backdrop-blur-md border-b border-gray-50 z-10">
        <button onClick={onBack} className="w-10 h-10 rounded-full border border-gray-100 flex items-center justify-center hover:bg-gray-50 shrink-0">
           <ChevronLeft className="w-6 h-6 text-gray-900" />
        </button>
        <h2 className="text-lg font-bold text-gray-900 flex-1 text-center pr-10">Add Property</h2>
      </div>

      <div className="flex-1 px-6 py-6 overflow-y-auto">
         {/* Step Indicator */}
         <div className="flex items-center gap-2 mb-8">
            {[1,2,3].map(s => (
               <div key={s} className="flex-1 flex items-center gap-2">
                  <div className={`h-1.5 flex-1 rounded-full ${s <= step ? 'bg-primary' : 'bg-gray-100'}`}></div>
               </div>
            ))}
         </div>

         <h3 className="text-xl font-bold text-gray-900 mb-6">Basic Information</h3>
         
         <div className="flex flex-col gap-5 mb-8">
            <div className="space-y-2">
               <label className="text-sm font-bold text-gray-700">Property Title</label>
               <input type="text" placeholder="Enter property title" className="w-full bg-gray-50 border border-gray-200 rounded-2xl px-5 py-3.5 text-sm font-medium text-gray-900 focus:border-primary/50 focus:ring-2 focus:ring-primary/10 outline-none" />
            </div>

            <div className="space-y-2">
               <label className="text-sm font-bold text-gray-700">Property Type</label>
               <select className="w-full bg-gray-50 border border-gray-200 rounded-2xl px-5 py-3.5 text-sm font-medium text-gray-900 focus:border-primary/50 focus:ring-2 focus:ring-primary/10 outline-none appearance-none">
                  <option>Apartment</option>
                  <option>House</option>
                  <option>Studio</option>
               </select>
            </div>

            <div className="space-y-2">
               <label className="text-sm font-bold text-gray-700">Price (per month)</label>
               <div className="relative">
                 <span className="absolute left-5 top-1/2 -translate-y-1/2 font-bold text-gray-400">$</span>
                 <input type="number" placeholder="0.00" className="w-full bg-gray-50 border border-gray-200 rounded-2xl pl-10 pr-5 py-3.5 text-sm font-bold text-gray-900 focus:border-primary/50 focus:ring-2 focus:ring-primary/10 outline-none" />
               </div>
            </div>

            <div className="space-y-2">
               <label className="text-sm font-bold text-gray-700">Location</label>
               <input type="text" placeholder="Enter location" className="w-full bg-gray-50 border border-gray-200 rounded-2xl px-5 py-3.5 text-sm font-medium text-gray-900 focus:border-primary/50 focus:ring-2 focus:ring-primary/10 outline-none" />
            </div>
         </div>
      </div>

      <div className="p-6 bg-white border-t border-gray-100">
         <button 
           onClick={() => { if(step < 3) setStep(step + 1); else onPublish(); }}
           className="w-full h-14 bg-primary text-white rounded-2xl font-bold text-[15px] shadow-lg shadow-primary/30 active:scale-[0.98] transition-transform"
         >
           {step === 3 ? 'Publish Property' : 'Next'}
         </button>
      </div>
    </div>
  );
}
