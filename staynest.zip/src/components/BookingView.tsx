import { useState } from 'react';
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight } from 'lucide-react';

export default function BookingView({ propertyId, onBack, onComplete }: { propertyId: string, onBack: () => void, onComplete: () => void }) {
  const dates = [
    { day: 'Mo', num: '1' }, { day: 'Tu', num: '2' }, { day: 'We', num: '3' }, 
    { day: 'Th', num: '4' }, { day: 'Fr', num: '5' }, { day: 'Sa', num: '6' }, { day: 'Su', num: '7' },
    { day: 'Mo', num: '8' }, { day: 'Tu', num: '9' }, { day: 'We', num: '10' }, 
    { day: 'Th', num: '11' }, { day: 'Fr', num: '12' }, { day: 'Sa', num: '13', active: true }, { day: 'Su', num: '14' },
    { day: 'Mo', num: '15' }, { day: 'Tu', num: '16' }, { day: 'We', num: '17' }, 
  ];

  const times = ['09:00 AM', '11:00 AM', '01:00 PM', '03:00 PM', '05:00 PM'];
  const [selectedTime, setSelectedTime] = useState('01:00 PM');

  return (
    <div className="flex-1 w-full bg-white flex flex-col h-full animate-in fade-in slide-in-from-right-4 duration-300 z-50 absolute inset-0">
      <div className="px-6 py-6 flex items-center sticky top-0 bg-white/80 backdrop-blur-md border-b border-gray-50">
        <button onClick={onBack} className="w-10 h-10 rounded-full border border-gray-100 flex items-center justify-center hover:bg-gray-50 shrink-0">
           <ChevronLeft className="w-6 h-6 text-gray-900" />
        </button>
        <h2 className="text-lg font-bold text-gray-900 flex-1 text-center pr-10">Book a Visit</h2>
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-6 flex flex-col">
          <h3 className="text-[15px] font-bold text-gray-900 mb-4">Select Date</h3>
          
          <div className="flex justify-between items-center mb-6">
             <button className="p-1"><ChevronLeft className="w-5 h-5 text-gray-400" /></button>
             <span className="font-bold text-gray-900">May 2024</span>
             <button className="p-1"><ChevronRight className="w-5 h-5 text-gray-900" /></button>
          </div>

          <div className="grid grid-cols-7 gap-y-4 gap-x-2 text-center mb-10">
             {['Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa', 'Su'].map(d => (
                <div key={d} className="text-[11px] font-bold text-gray-400 mb-2">{d}</div>
             ))}
             {dates.map((d, i) => (
                <button 
                  key={i} 
                  className={`w-10 h-10 mx-auto rounded-full flex items-center justify-center text-sm font-semibold transition-colors
                    ${d.active ? 'bg-primary text-white shadow-md shadow-primary/30' : 'text-gray-700 hover:bg-gray-100'}`
                  }
                >
                  {d.num}
                </button>
             ))}
          </div>

          <h3 className="text-[15px] font-bold text-gray-900 mb-4">Select Time</h3>
          <div className="flex flex-wrap gap-3 mb-10">
             {times.map(t => (
               <button 
                 key={t}
                 onClick={() => setSelectedTime(t)}
                 className={`px-4 py-2.5 rounded-xl text-[13px] font-semibold transition-all border
                   ${t === selectedTime 
                      ? 'bg-primary text-white border-primary shadow-sm shadow-primary/20' 
                      : 'bg-white text-gray-600 border-gray-200 hover:border-gray-300'}`
                 }
               >
                 {t}
               </button>
             ))}
          </div>

          <div className="mt-auto pt-6 border-t border-gray-100">
             <button 
               onClick={onComplete}
               className="w-full h-14 bg-primary text-white rounded-2xl font-bold text-[15px] shadow-lg shadow-primary/30 active:scale-[0.98] transition-transform"
             >
               Confirm Booking
             </button>
          </div>
      </div>
    </div>
  );
}
