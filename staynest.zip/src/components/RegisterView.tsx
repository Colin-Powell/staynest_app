import { useState } from 'react';

export default function RegisterView({ onRegister, onLogin }: { onRegister: () => void, onLogin: () => void }) {
  return (
    <div className="flex-1 w-full bg-white flex flex-col h-full animate-in fade-in zoom-in-95 duration-300">
      <div className="flex-1 overflow-y-auto px-6 py-12 flex flex-col">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Create Account</h1>
        <p className="text-gray-500 mb-8 font-medium text-[15px]">Sign up to get started</p>
        
        <div className="flex flex-col gap-4 mb-8">
          <input 
            type="text" 
            placeholder="Full name" 
            className="w-full bg-gray-50/50 border border-gray-200 rounded-2xl px-5 py-4 text-[15px] font-medium text-gray-900 placeholder-gray-400 focus:outline-none focus:border-primary/50 focus:ring-2 focus:ring-primary/10 transition-all"
          />
          <input 
            type="tel" 
            placeholder="Phone number" 
            className="w-full bg-gray-50/50 border border-gray-200 rounded-2xl px-5 py-4 text-[15px] font-medium text-gray-900 placeholder-gray-400 focus:outline-none focus:border-primary/50 focus:ring-2 focus:ring-primary/10 transition-all"
          />
          <input 
            type="email" 
            placeholder="Email address" 
            className="w-full bg-gray-50/50 border border-gray-200 rounded-2xl px-5 py-4 text-[15px] font-medium text-gray-900 placeholder-gray-400 focus:outline-none focus:border-primary/50 focus:ring-2 focus:ring-primary/10 transition-all"
          />
          <input 
            type="password" 
            placeholder="Password" 
            className="w-full bg-gray-50/50 border border-gray-200 rounded-2xl px-5 py-4 text-[15px] font-medium text-gray-900 placeholder-gray-400 focus:outline-none focus:border-primary/50 focus:ring-2 focus:ring-primary/10 transition-all"
          />
        </div>

        <button 
          onClick={onRegister}
          className="w-full h-14 bg-primary text-white rounded-2xl font-bold text-[15px] shadow-lg shadow-primary/30 active:scale-[0.98] transition-transform mb-8"
        >
          Sign up
        </button>

        <div className="flex items-center gap-4 mb-8">
           <div className="h-[1px] bg-gray-200 flex-1"></div>
           <span className="text-[13px] font-semibold text-gray-400">Or continue with</span>
           <div className="h-[1px] bg-gray-200 flex-1"></div>
        </div>

        <div className="flex gap-4 mb-8">
           <button className="flex-1 h-14 rounded-2xl border border-gray-200 flex items-center justify-center gap-2 hover:bg-gray-50 active:scale-[0.98] transition-all">
              <svg className="w-5 h-5" viewBox="0 0 24 24"><path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/><path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/><path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/><path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/><path d="M1 1h22v22H1z" fill="none"/></svg>
           </button>
           <button className="flex-1 h-14 rounded-2xl border border-gray-200 flex items-center justify-center gap-2 hover:bg-gray-50 active:scale-[0.98] transition-all">
              <svg className="w-5 h-5 fill-black" viewBox="0 0 24 24"><path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.04 2.27-.79 3.51-.79 1.48.04 2.75.59 3.55 1.6-3.16 1.93-2.61 5.92.5 7.15-.69 1.77-1.52 3.19-2.64 4.21M12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25"/></svg>
           </button>
        </div>
        
        <div className="mt-auto flex justify-center pb-4 text-[13px] font-semibold text-gray-500">
           Already have an account? <button onClick={onLogin} className="text-primary ml-1 hover:underline">Login</button>
        </div>
      </div>
    </div>
  );
}
