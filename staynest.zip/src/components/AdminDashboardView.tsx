import { Users, FileText, AlertTriangle, ShieldCheck, TrendingUp, MoreHorizontal, Check, X } from 'lucide-react';
import { formatPrice } from '../data';

export default function AdminDashboardView() {
  return (
    <div className="flex-1 overflow-y-auto w-full bg-[#f8f9fa] no-scrollbar pb-28">
      <div className="px-6 pt-12 pb-4 bg-[#f8f9fa] sticky top-0 z-10 flex justify-between items-center">
         <h1 className="text-xl font-bold text-gray-900">Admin Dashboard</h1>
         <div className="w-10 h-10 bg-primary/10 text-primary rounded-full flex items-center justify-center relative shadow-sm">
            <ShieldCheck className="w-5 h-5" />
         </div>
      </div>

      <div className="px-6 py-2">
        <div className="flex gap-4 mb-6">
          <div className="flex-1 bg-white p-4 rounded-3xl shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 text-gray-500 mb-2">
              <Users className="w-4 h-4" />
              <span className="text-xs font-bold">Users</span>
            </div>
            <div className="text-xl font-bold text-gray-900 mb-1">12,345</div>
            <div className="text-[10px] font-bold text-green-500 flex items-center gap-1">
              <TrendingUp className="w-3 h-3" /> +12%
            </div>
          </div>
          <div className="flex-1 bg-white p-4 rounded-3xl shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 text-gray-500 mb-2">
              <FileText className="w-4 h-4" />
              <span className="text-xs font-bold">Listings</span>
            </div>
            <div className="text-xl font-bold text-gray-900 mb-1">8,765</div>
            <div className="text-[10px] font-bold text-green-500 flex items-center gap-1">
              <TrendingUp className="w-3 h-3" /> +12%
            </div>
          </div>
          <div className="flex-1 bg-white p-4 rounded-3xl shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 text-gray-500 mb-2">
              <span className="text-xs font-bold">Revenue</span>
            </div>
            <div className="text-xl font-bold text-gray-900 mb-1">1.2M</div>
            <div className="text-[10px] font-bold text-green-500 flex items-center gap-1">
              <TrendingUp className="w-3 h-3" /> +8%
            </div>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4 mb-8">
           <div className="bg-white rounded-2xl p-3 flex flex-col items-center justify-center gap-1 shadow-sm border border-gray-100">
             <span className="text-2xl font-bold text-gray-900">45</span>
             <span className="text-[11px] font-semibold text-gray-400">Reports</span>
           </div>
           <div className="bg-white rounded-2xl p-3 flex flex-col items-center justify-center gap-1 shadow-sm border border-gray-100">
             <span className="text-2xl font-bold text-gray-900">97</span>
             <span className="text-[11px] font-semibold text-gray-400">Verifications</span>
           </div>
           <div className="bg-white rounded-2xl p-3 flex flex-col items-center justify-center gap-1 shadow-sm border border-gray-100">
             <span className="text-2xl font-bold text-red-500">23</span>
             <span className="text-[11px] font-semibold text-gray-400">Suspended</span>
           </div>
        </div>

        <h2 className="text-[17px] font-bold text-gray-900 mb-4">Pending Verifications</h2>
        
        <div className="flex flex-col gap-4 mb-6">
          {[1, 2].map((i) => (
             <div key={i} className="bg-white rounded-3xl p-3 flex gap-4 shadow-sm border border-gray-100 items-center">
                <div className="w-14 h-14 bg-gray-200 rounded-2xl overflow-hidden shrink-0">
                  <img src={`https://images.unsplash.com/photo-${i === 1 ? '1600596542815-ffad4c1539a9' : '1560448204-e02f11c3d0e2'}?auto=format&fit=crop&q=80&w=150`} alt="listing" className="w-full h-full object-cover" />
                </div>
                <div className="flex-1">
                   <h3 className="font-bold text-[14px] text-gray-900 leading-tight">Luxury Bedsitter</h3>
                   <p className="text-xs font-semibold text-gray-500 mb-1">Woodlands, Nairobi</p>
                   <p className="font-bold text-primary text-[13px]">{formatPrice(15000)}</p>
                </div>
                <div className="flex flex-col gap-2">
                   <button className="w-8 h-8 rounded-full bg-green-50 text-green-500 flex items-center justify-center border border-green-100">
                     <Check className="w-4 h-4" />
                   </button>
                   <button className="w-8 h-8 rounded-full bg-red-50 text-red-500 flex items-center justify-center border border-red-100">
                     <X className="w-4 h-4" />
                   </button>
                </div>
             </div>
          ))}
          <button className="text-primary font-bold text-[13px] hover:underline self-center mt-2">View All</button>
        </div>

        <h2 className="text-[17px] font-bold text-gray-900 mb-4">Recent Reports</h2>
        <div className="bg-white rounded-3xl p-4 shadow-sm border border-gray-100 flex items-center gap-4">
           <div className="w-10 h-10 rounded-full bg-orange-100 text-orange-500 flex items-center justify-center shrink-0">
              <AlertTriangle className="w-5 h-5" />
           </div>
           <div className="flex-1">
              <h4 className="font-bold text-[14px] text-gray-900">Fake Listing Report</h4>
              <p className="text-xs font-semibold text-gray-500">Modern Apartment in Kilimani</p>
           </div>
           <span className="text-[11px] font-semibold text-gray-400">10 min ago</span>
        </div>
      </div>
    </div>
  );
}
