import { ChevronLeft, Info, Send, Phone, Video } from 'lucide-react';
import { useState } from 'react';

export default function ChatView({ onBack, onCall, name, avatar }: { onBack: () => void, onCall?: () => void, name: string, avatar: string }) {
  const [msg, setMsg] = useState('');
  
  return (
    <div className="flex-1 w-full bg-slate-50 flex flex-col h-full animate-in fade-in slide-in-from-right-4 duration-300 z-50 absolute inset-0">
      
      {/* Header */}
      <div className="px-6 py-4 pt-12 flex items-center justify-between sticky top-0 bg-white shadow-sm z-10 border-b border-gray-100">
        <div className="flex items-center gap-3">
            <button onClick={onBack} className="w-10 h-10 -ml-2 rounded-full flex items-center justify-center hover:bg-gray-50 flex-shrink-0">
               <ChevronLeft className="w-6 h-6 text-gray-900" />
            </button>
            <div className="flex items-center gap-2">
                <img src={avatar} alt={name} className="w-10 h-10 rounded-full object-cover shadow-sm bg-gray-100" />
                <div>
                   <h2 className="text-[15px] font-bold text-gray-900 leading-tight">{name}</h2>
                   <div className="flex items-center gap-1">
                      <div className="w-1.5 h-1.5 rounded-full bg-green-500"></div>
                      <span className="text-[11px] font-semibold text-gray-500">Online</span>
                   </div>
                </div>
            </div>
        </div>
        <div className="flex items-center gap-2 text-gray-900">
           <button onClick={onCall} className="w-10 h-10 rounded-full flex items-center justify-center hover:bg-gray-50"><Phone className="w-5 h-5 fill-current" /></button>
        </div>
      </div>

      {/* Chat Area */}
      <div className="flex-1 overflow-y-auto px-6 py-6 flex flex-col gap-4">
        
        <div className="flex justify-center mb-2">
           <span className="px-3 py-1 bg-black/5 rounded-full text-[11px] font-bold text-gray-500">Today</span>
        </div>

        {/* Their message */}
        <div className="flex gap-2 max-w-[85%] self-start">
           <img src={avatar} alt={name} className="w-8 h-8 rounded-full object-cover shrink-0 self-end mb-1" />
           <div className="bg-white border border-gray-100 p-4 rounded-[1.25rem] rounded-bl-sm shadow-sm">
              <p className="text-[14.5px] font-medium text-gray-700">Hi, is the room still available?</p>
              <div className="text-[10px] font-bold text-gray-400 mt-1 text-right">10:45 AM</div>
           </div>
        </div>

        {/* My message */}
        <div className="flex gap-2 max-w-[85%] self-end flex-row-reverse">
           <div className="bg-primary text-white p-4 rounded-[1.25rem] rounded-br-sm shadow-sm shadow-primary/20">
              <p className="text-[14.5px] font-medium">Yes, it is available. When would you like to come for a viewing?</p>
              <div className="text-[10px] font-bold text-white/70 mt-1 text-right">10:48 AM</div>
           </div>
        </div>

        {/* Their message */}
        <div className="flex gap-2 max-w-[85%] self-start">
           <img src={avatar} alt={name} className="w-8 h-8 rounded-full object-cover shrink-0 self-end mb-1" />
           <div className="bg-white border border-gray-100 p-4 rounded-[1.25rem] rounded-bl-sm shadow-sm">
              <p className="text-[14.5px] font-medium text-gray-700">Tomorrow at 11 AM works for me.</p>
              <div className="text-[10px] font-bold text-gray-400 mt-1 text-right">10:50 AM</div>
           </div>
        </div>

        {/* My message */}
        <div className="flex gap-2 max-w-[85%] self-end flex-row-reverse">
           <div className="bg-primary text-white p-4 rounded-[1.25rem] rounded-br-sm shadow-sm shadow-primary/20">
              <p className="text-[14.5px] font-medium">Great! See you tomorrow.</p>
              <div className="text-[10px] font-bold text-white/70 mt-1 text-right">10:52 AM</div>
           </div>
        </div>

      </div>

      {/* Input Area */}
      <div className="p-4 px-6 bg-white border-t border-gray-100 sticky bottom-0 z-30 pb-8 rounded-b-[inherit]">
         <div className="flex items-center gap-2 bg-gray-50 rounded-2xl px-2 py-1.5 border border-gray-200 focus-within:border-primary/50 focus-within:ring-2 focus-within:ring-primary/10 transition-all">
            <button className="w-10 h-10 rounded-full flex items-center justify-center text-gray-400 hover:text-gray-600">
               <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            </button>
            <input 
              type="text" 
              placeholder="Type a message..."
              className="flex-1 bg-transparent border-none outline-none font-medium text-[15px] text-gray-900 placeholder-gray-400 py-2 min-w-0"
              value={msg}
              onChange={e => setMsg(e.target.value)}
            />
            <button className="w-10 h-10 rounded-full flex items-center justify-center text-primary hover:bg-primary/10 bg-primary/5 font-bold transition-colors">
               <Send className="w-5 h-5 ml-0.5" />
            </button>
         </div>
      </div>
    
    </div>
  );
}
