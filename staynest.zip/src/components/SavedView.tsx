import { Heart, MapPin, Star } from 'lucide-react';
import { formatPrice, properties } from '../data';

export default function SavedView({ onSelectProperty }: { onSelectProperty: (id: string) => void }) {
  return (
    <div className="flex-1 overflow-y-auto w-full bg-[#f8f9fa] no-scrollbar pb-24 animate-in fade-in zoom-in-95 duration-200">
      <div className="px-6 pt-12 pb-4 bg-[#f8f9fa] sticky top-0 z-10">
          <h1 className="text-xl font-bold text-gray-900">Saved Properties</h1>
      </div>

      <div className="px-6 py-6 flex flex-col gap-4 pb-28">
        {properties.map((property) => (
          <div
            key={`saved-${property.id}`}
            className="bg-white rounded-3xl p-3 flex gap-4 cursor-pointer items-center relative hover:shadow-[0_8px_30px_rgba(0,0,0,0.06)] transition-shadow"
            onClick={() => onSelectProperty(property.id)}
          >
            <button 
                onClick={(e) => { e.stopPropagation(); }}
                className="absolute top-4 right-4 p-1 rounded-full text-red-500 bg-white/80 backdrop-blur-md hover:scale-110 active:scale-95 transition-transform z-10"
            >
                <Heart className="w-5 h-5 fill-red-500 relative top-[0.5px]" />
            </button>
            <div className="w-[100px] h-[100px] rounded-[1.25rem] overflow-hidden shrink-0">
              <img src={property.image} alt={property.name} className="w-full h-full object-cover" />
            </div>
            <div className="flex-1 min-w-0 py-1 pr-8">
              <h3 className="font-bold text-gray-900 truncate mb-1">{property.name}</h3>
              <div className="flex items-center text-gray-500 text-[13px] mb-2">
                 <MapPin className="w-[14px] h-[14px] mr-1 shrink-0 text-gray-400" />
                 <p className="truncate block font-medium">{property.location}</p>
              </div>
              <div className="flex items-center gap-1 font-bold text-primary text-[15px] mb-1.5">
                {formatPrice(property.price)}<span className="text-[10px] font-semibold text-gray-400 font-sans">/month</span>
              </div>
              <div className="flex items-center gap-1 text-gray-600 text-xs font-semibold">
                  <Star className="w-3 h-3 text-orange-400 fill-orange-400 relative -top-[0.5px]" />
                  {property.rating} <span className="text-gray-400 font-medium">({property.reviews})</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
