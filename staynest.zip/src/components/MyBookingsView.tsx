import { ChevronLeft, Calendar } from 'lucide-react';
import { useState } from 'react';
import { properties } from '../data';

export default function MyBookingsView({ onBack }: { onBack: () => void }) {
  const [tab, setTab] = useState('Upcoming');

  return (
    <div className="flex-1 w-full bg-[#f8f9fa] flex flex-col h-full animate-in fade-in slide-in-from-right-4 duration-300 z-50 absolute inset-0">
      <div className="px-6 pt-12 pb-4 flex items-center sticky top-0 bg-[#f8f9fa] z-10">
        <button onClick={onBack} className="w-10 h-10 rounded-full border border-gray-100 flex items-center justify-center bg-white hover:bg-gray-50 flex-shrink-0 shadow-sm">
           <ChevronLeft className="w-5 h-5 text-gray-700" />
        </button>
        <h2 className="text-xl font-bold text-gray-900 flex-1 text-center pr-10">My Bookings</h2>
      </div>

      <div className="px-6 py-4 flex gap-2 overflow-x-auto no-scrollbar bg-[#f8f9fa] sticky top-[73px] z-10 pb-4">
        {['Upcoming', 'Completed', 'Cancelled'].map(t => (
          <button 
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-2 rounded-full text-[13px] font-bold transition-all whitespace-nowrap
              ${tab === t ? 'bg-primary/10 text-primary' : 'bg-transparent text-gray-500'}`
            }
          >
            {t}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto px-6 py-4 flex flex-col gap-4 pb-28">
         {properties.map((property, i) => (
           <div key={property.id} className="bg-white rounded-3xl p-4 flex gap-4 hover:shadow-[0_8px_30px_rgba(0,0,0,0.06)] transition-shadow relative">
               <div className="w-[80px] h-[80px] rounded-[1.25rem] overflow-hidden shrink-0">
                 <img src={property.image} alt={property.name} className="w-full h-full object-cover" />
               </div>
               <div className="flex-1 flex flex-col">
                  <h3 className="font-bold text-gray-900 mb-1">{property.name}</h3>
                  <p className="text-sm font-semibold text-gray-500 mb-2">{property.location}</p>
                  <div className="flex items-center gap-2 text-xs font-semibold text-gray-600 mb-3">
                    <Calendar className="w-3.5 h-3.5" />
                    May 15, 2024 - 01:00 PM
                  </div>
                  
                 {tab === 'Upcoming' && i === 0 && (
                    <div className="bg-primary/5 text-primary text-xs font-bold px-3 py-1.5 rounded-lg w-fit">
                      Scheduled
                    </div>
                 )}
                 {tab === 'Upcoming' && i === 1 && (
                    <div className="bg-green-500/10 text-green-600 text-xs font-bold px-3 py-1.5 rounded-lg w-fit">
                      Confirmed
                    </div>
                 )}
                 {tab === 'Upcoming' && i === 2 && (
                    <div className="bg-red-500/10 text-red-500 text-xs font-bold px-3 py-1.5 rounded-lg w-fit">
                      Cancelled
                    </div>
                 )}
               </div>
           </div>
         ))}
      </div>
    </div>
  );
}
