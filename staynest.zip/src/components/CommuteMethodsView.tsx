import { ChevronLeft, Bus, Navigation, Bike } from 'lucide-react';
import { MapContainer, TileLayer, Marker, Polyline } from 'react-leaflet';

export default function CommuteMethodsView({ onClose }: { onClose: () => void }) {
  const positionA: [number, number] = [-1.2921, 36.8219];
  const positionB: [number, number] = [-1.2800, 36.8150];

  return (
    <div className="flex-1 w-full bg-[#f8f9fa] flex flex-col h-full animate-in fade-in slide-in-from-right-4 duration-300 z-50 absolute inset-0">
      <div className="px-6 pt-12 pb-4 flex items-center sticky top-0 bg-[#f8f9fa] z-10">
        <button onClick={onClose} className="w-10 h-10 rounded-full border border-gray-100 flex items-center justify-center bg-white hover:bg-gray-50 flex-shrink-0 shadow-sm">
           <ChevronLeft className="w-5 h-5 text-gray-700" />
        </button>
        <h2 className="text-xl font-bold text-gray-900 flex-1 text-center pr-10">Commute Estimation</h2>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar pb-32">
        <div className="px-6 pb-6">
           <div className="bg-white p-4 rounded-3xl border border-gray-100 shadow-sm relative">
              <div className="absolute left-6 top-[3.5rem] bottom-[3.5rem] w-px bg-gray-200"></div>
              
              <div className="mb-4 relative">
                 <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider ml-6 mb-1">From</p>
                 <div className="flex items-center gap-3">
                    <div className="w-2.5 h-2.5 rounded-full border-2 border-primary bg-white z-10 shadow-sm"></div>
                    <span className="font-bold text-[15px] text-gray-900">Kilimani, Nairobi</span>
                 </div>
              </div>
              
              <div className="relative">
                 <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider ml-6 mb-1">To</p>
                 <div className="flex items-center gap-3">
                    <div className="w-2.5 h-2.5 rounded-full bg-primary z-10 shadow-sm"></div>
                    <span className="font-bold text-[15px] text-gray-900">University of Nairobi</span>
                 </div>
              </div>
           </div>
        </div>

        <div className="px-6 mb-6">
           <div className="flex gap-4">
              <button className="flex-1 bg-primary text-white p-4 rounded-3xl flex flex-col items-center justify-center gap-2 shadow-[0_8px_20px_-6px_rgba(78,70,229,0.4)]">
                 <Bus className="w-6 h-6" />
                 <div className="text-center">
                    <span className="block text-[11px] font-medium text-white/80">Matatu</span>
                    <span className="block font-bold text-[15px]">15 min</span>
                 </div>
              </button>
              <button className="flex-1 bg-white border border-gray-100 text-gray-500 hover:bg-gray-50 p-4 rounded-3xl flex flex-col items-center justify-center gap-2 shadow-sm transition-colors">
                 <Navigation className="w-6 h-6" />
                 <div className="text-center">
                    <span className="block text-[11px] font-medium">Walk</span>
                    <span className="block font-bold text-[15px] text-gray-900">32 min</span>
                 </div>
              </button>
              <button className="flex-1 bg-white border border-gray-100 text-gray-500 hover:bg-gray-50 p-4 rounded-3xl flex flex-col items-center justify-center gap-2 shadow-sm transition-colors">
                 <Bike className="w-6 h-6" />
                 <div className="text-center">
                    <span className="block text-[11px] font-medium">Boda</span>
                    <span className="block font-bold text-[15px] text-gray-900">6 min</span>
                 </div>
              </button>
           </div>
        </div>

        <div className="h-[250px] w-full z-0 relative px-6">
           <h3 className="text-[15px] font-bold text-gray-900 mb-3">Best Route</h3>
           <div className="w-full h-full rounded-[2rem] overflow-hidden shadow-sm border border-gray-100 leading-[0]">
              <MapContainer center={[-1.2860, 36.8180]} zoom={14} zoomControl={false} className="w-full h-full z-0">
                 <TileLayer url="https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png" />
                 <Marker position={positionA} />
                 <Marker position={positionB} />
                 <Polyline positions={[positionA, positionB]} color="#4F46E5" weight={4} dashArray="8" />
              </MapContainer>
           </div>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 p-6 bg-white z-30 shadow-[0_-10px_20px_rgba(0,0,0,0.02)] pb-8">
         <button className="w-full h-14 bg-primary text-white rounded-[1.2rem] font-bold text-[15px] shadow-[0_8px_20px_-6px_rgba(78,70,229,0.4)] active:scale-[0.98] transition-transform flex items-center justify-center gap-2">
           <Navigation className="w-4 h-4 fill-current" /> Start Navigation
         </button>
      </div>
    </div>
  );
}
